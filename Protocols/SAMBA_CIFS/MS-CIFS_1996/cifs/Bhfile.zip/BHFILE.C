//#strings 0002 (Don't touch this)

//=============================================================================
//  Microsoft (R) Bloodhound (tm). Copyright (C) 1991-1992.
//
//  MODULE: bhfile.c
//
//  Description:
//
//  This source file contains internal functions for manipulating bloodhound files.
//
//  Modification History
//
//  raypa           12/16/92            Created
//  raypa           12/27/92            Added SaveBloodhoundCapture and SaveTextCapture.
//  Tom McConnell   12/29/92            Changed to use new GetMappedFilePointer
//=============================================================================

#include "bhkrnl.h"
#include "strings.h"

extern LPSTR ids(UINT idsString);

//=============================================================================
//  FUNCTION: GetMinCaptureFileSize()
//
//  Modification History
//
//  raypa       03/02/94            Created
//=============================================================================

DWORD WINAPI GetMinCaptureFileSize(LPCAPTUREFILE CaptureFile)
{
    DWORD FrameTableSize, UserDataSize, CommentDataSize, MaxSize;
    DWORD Version;

    //=========================================================================
    //  Calculate the size of each member of this file.
    //=========================================================================

    FrameTableSize  = CaptureFile->Header.FrameTableOffset + CaptureFile->Header.FrameTableLength;

    UserDataSize = CaptureFile->Header.UserDataOffset + CaptureFile->Header.UserDataLength;

    //=========================================================================
    //  Add in the comment offset + length if the BH version is not than 1.0.
    //=========================================================================

    Version = MakeVersion(CaptureFile->Header.BCDVerMinor, CaptureFile->Header.BCDVerMajor);

    if ( Version >= MakeVersion(1, 1) )
    {
        CommentDataSize = CaptureFile->Header.CommentDataOffset + CaptureFile->Header.CommentDataLength;
    }
    else
    {
        CommentDataSize = 0;
    }

    MaxSize = max(max(FrameTableSize, UserDataSize), CommentDataSize);

    //=========================================================================
    //  Return the maximum offset + length found in this file. This size
    //  is the minimum required for the capture file to be valid.
    //=========================================================================

    return MaxSize;
}

//=============================================================================
//  FUNCTION: LoadBloodhoundCapture()
//
//  Modification History
//
//  raypa       12/18/92            Created
//  raypa       07/12/93            Checked file length.
//=============================================================================

DWORD WINAPI LoadBloodhoundCapture(LPCAPTURE lpCapture, LPSTR FileName)
{
    LPCAPTUREFILE   lpCaptureFile;
    DWORD           nFrames;
    DWORD           Attrib;
    DWORD           MapAccess;

#ifdef DEBUG
    dprintf("LoadBloodhoundCapture entered.\r\n");
#endif

    //=========================================================================
    //  Figure out how to map this puppy by its file attributes.
    //=========================================================================

    Attrib = GetFileAttributes(FileName);

    MapAccess = FILE_MAP_READ;

    /* We only need read access to this file...
    if ( (Attrib & FILE_ATTRIBUTE_READONLY) != 0 )
    {
        MapAccess = FILE_MAP_READ;
    }
    else
    {
        MapAccess = FILE_MAP_WRITE;
    }
    */

    //=========================================================================
    //  Map file handle to a memory-mapped pointer.
    //=========================================================================

    lpCaptureFile = GetMappedFilePointer(lpCapture->hFile,
                                         &lpCapture->hFileMapping,
                                         MapAccess,
                                         0,
                                         0);

    if ( lpCaptureFile != (LPCAPTUREFILE) NULL )
    {
        //=====================================================================
        //  Check for Bloodhound signature.
        //=====================================================================

        if ( lpCaptureFile->Header.Signature == CAPTUREFILE_SIGNATURE )
        {
            //=================================================================
            //  Verify the file contents.
            //=================================================================

            if ( lpCapture->FileSize < GetMinCaptureFileSize(lpCaptureFile) )
            {
                MessageBox(GetActiveWindow(),
                           ids(IDS_BHFILE_C_1),
                           ids(IDS_BHFILE_C_2),
                           MB_OK | MB_ICONSTOP | MB_APPLMODAL);
            }

            //=================================================================
            //  Create a frame table for this capture context.
            //=================================================================

            nFrames = lpCaptureFile->Header.FrameTableLength / sizeof(DWORD);

            lpCapture->FrameTable = CreateFrameTable(nFrames);

            if ( lpCapture->FrameTable != NULL )
            {
                //=============================================================
                //  Initialize the capture context structure.
                //=============================================================

                lpCapture->CaptureFile = lpCaptureFile;
                lpCapture->MacType     = (WORD) lpCaptureFile->Header.MacType;

                memcpy(&lpCapture->TimeStamp, &lpCaptureFile->Header.TimeStamp, sizeof(SYSTEMTIME));

                return BHERR_SUCCESS;
            }
            
            ReleaseMappedFilePointer(lpCaptureFile, lpCapture->hFileMapping);
            
            return BHERR_OUT_OF_MEMORY;
        }

        ReleaseMappedFilePointer(lpCaptureFile, lpCapture->hFileMapping);
        
        return BHERR_INVALID_FILE_FORMAT;
    }

    return BHERR_MEMORY_MAPPED_FILE_ERROR;
}

//=============================================================================
//  FUNCTION: SaveBloodhoundCapture()
//
//  Modification History
//
//  raypa               12/27/92            Created
//  Tom McConnell       02/18/93            Fixed lastframe miscalc...
//  raypa               03/30/93            Changed to update file format.
//  Tom Laird-McConnell 11/07/93            Added lpComment field
//  Tom Laird-McConnell 12/01/93            Fixed errrogneous modifying of 
//                                          lpCaptureFile pointer
//  raypa               01/15/94            Changed from mem-mapped files to disk writes.
//  raypa               01/28/94            Fixed bug in saving comment.
//  Tom LAird-McConnell 06/07/94            added error handling for all Write's
//=============================================================================

//... Bigger is not better, to not increase.

#define CACHE_BLOCK_SIZE        (256 * 1024)

DWORD WINAPI SaveBloodhoundCapture(HANDLE     hFile,
                                   LPCAPTURE  lpCapture,
                                   LPSTR      lpComment,
                                   LPVOID     UserData,
                                   DWORD      UserDataLength,
                                   FILTERPROC FilterProc,
                                   LPVOID     FilterInstData,
                                   DWORD      nFirstFrame,
                                   DWORD      nLastFrame)
{
    CAPTUREFILE CaptureFile;
    DWORD       BytesWritten;
    DWORD       FileOffset;
    DWORD       FrameSize, i, j;
    LPDWORD     FrameTable;
    DWORD       FrameTableSize;
    LPBYTE      CacheBlock;
    DWORD       CurrentPos;
    DWORD       CommentLength;

#ifdef DEBUG
    DWORD StartTime, EndTime;

    dprintf("SaveBloodhoundCapture entered\r\n");

    StartTime = clock();
#endif

    //=========================================================================
    //  If there is no frame table then this capture contains has no frames.
    //=========================================================================

    if ( lpCapture->FrameTable == NULL )
        return(BHSetLastError(BHERR_NO_FRAMES));

    //=========================================================================
    //  Build as much of the header as we can up front.
    //=========================================================================

    memset(&CaptureFile, 0, CAPTUREFILE_SIZE);

    CaptureFile.Header.Signature   = CAPTUREFILE_SIGNATURE;
    CaptureFile.Header.BCDVerMajor = VERSION_MAJOR;
    CaptureFile.Header.BCDVerMinor = VERSION_MINOR;
    CaptureFile.Header.MacType     = (WORD) lpCapture->MacType;

    memcpy(&CaptureFile.Header.TimeStamp,
           &lpCapture->TimeStamp,
           sizeof(SYSTEMTIME));

    //=========================================================================
    //  Write the header out.
    //=========================================================================

    if (WriteFile(hFile, &CaptureFile, CAPTUREFILE_SIZE, &BytesWritten, NULL) == FALSE)
        return(BHSetLastError(BHERR_WINDOWS_ERROR));

    FileOffset = CAPTUREFILE_SIZE;

    //=========================================================================
    //  Create a temp frame table.
    //=========================================================================

    FrameTableSize = FRAMETABLE_SIZE + lpCapture->FrameTable->nFrames *  sizeof(LPFRAMEDESC);

    if ( (FrameTable = AllocMemory(FrameTableSize)) == NULL )
        return BHSetLastError(BHERR_OUT_OF_MEMORY);

    //=========================================================================
    //  Allocate save buffer (cache block).
    //=========================================================================

    if ( (CacheBlock = AllocMemory(CACHE_BLOCK_SIZE)) == NULL )
    {
        FreeMemory(FrameTable);

        return BHSetLastError(BHERR_OUT_OF_MEMORY);
    }

    CurrentPos = 0;

    //=========================================================================
    //  Copy in the frames, filtering them as we go.
    //=========================================================================

    j = 0;
    for( i = nFirstFrame; i <= nLastFrame; ++i)
    {
        register LPFRAMEDESC lpFrameDesc;

        if ( (lpFrameDesc = GetFrame(lpCapture, i)) != NULL )
        {
            BOOL KeepFrame;

            //=================================================================
            //  Call back to the application to filter this frame.
            //  If the FilterProc pointer is NULL thena fault will
            //  occur and we will keep the frame by default.
            //=================================================================

            if ( FilterProc != (FILTERPROC) NULL )
            {
                DWORD Error;

                try
                {

                    Error = FilterProc(GetCaptureHandle(lpCapture), GetFrameHandle(lpFrameDesc), FilterInstData);

                    switch( Error )
                    {
                        case BHERR_SUCCESS:
                            KeepFrame = TRUE;
                            break;

                        case BHERR_DISCARD_FRAME:
                            KeepFrame = FALSE;
                            break;

                        case BHERR_CANCEL_SAVE_CAPTURE:
                            BHSetLastError(BHERR_CANCEL_SAVE_CAPTURE);
                            return BHERR_CANCEL_SAVE_CAPTURE;

                        default:
                            KeepFrame = TRUE;
                            break;
                    }
                }
                except(EXCEPTION_EXECUTE_HANDLER)
                {
                    KeepFrame = TRUE;
                }
            }
            else
            {
                KeepFrame = TRUE;
            }

            //=================================================================
            //  If the frame passed the filter then we copy into the file.
            //=================================================================

            if ( KeepFrame )
            {
                FrameSize = FRAME_SIZE + lpFrameDesc->Frame->nBytesAvail;

#ifdef DEBUG
                if ( lpFrameDesc->Frame->nBytesAvail == 0 )
                {
                    PanicPoint();
                }
#endif

                //===========================================================
                //  If the cache block is full, write to disk.
                //===========================================================

                if ( (CurrentPos + FrameSize) > CACHE_BLOCK_SIZE )
                {
                    if (WriteFile(hFile, CacheBlock, CurrentPos, &BytesWritten, NULL) == FALSE)
                    {
                        FreeMemory(CacheBlock);
                        FreeMemory(FrameTable);
                        return BHSetLastError(BHERR_WINDOWS_ERROR);
                    }

                    CurrentPos = 0;
                }

                //===========================================================
                //  Copy the frame into the file at the current location.
                //===========================================================

                memcpy(&CacheBlock[CurrentPos], (LPBYTE) lpFrameDesc->Frame, FrameSize);

                CurrentPos += FrameSize;

                //===========================================================
                //  Add this frame's offset to the frame index table.
                //===========================================================

                FrameTable[j++] = FileOffset;

                //===========================================================
                //  Update current location by the frame size.
                //===========================================================

                FileOffset += FrameSize;
            }
        }
    }

    //=======================================================================
    //  If the cache block contains any remaining data, flush it.
    //=======================================================================

    if ( CurrentPos != 0 )
    {
        if (WriteFile(hFile, CacheBlock, CurrentPos, &BytesWritten, NULL) == FALSE)
        {
            FreeMemory(CacheBlock);
            FreeMemory(FrameTable);
            return BHSetLastError(BHERR_WINDOWS_ERROR);
        }
    }

    FreeMemory(CacheBlock);

    //=======================================================================
    //  Now that we have copied all of the frames into the file, we
    //  have to put the frame index table into the file.
    //=======================================================================

    CaptureFile.Header.FrameTableOffset = FileOffset;
    CaptureFile.Header.FrameTableLength = sizeof(LPFRAMEDESC) * j;

    WriteFile(hFile, FrameTable, FrameTableSize, &BytesWritten, NULL);

    FileOffset += FrameTableSize;

    FreeMemory(FrameTable);

    //=======================================================================
    //  Copy the Comment, if there is any...
    //=======================================================================

    if ( lpComment != NULL )
    {
        if ( (CommentLength = strlen(lpComment)) != 0 )
        {
            CommentLength++;        //... Add 1 for NULL character.

            CaptureFile.Header.CommentDataOffset = FileOffset;
            CaptureFile.Header.CommentDataLength = CommentLength;

            if (WriteFile(hFile, lpComment, CommentLength, &BytesWritten, NULL) == FALSE)
                return BHSetLastError(BHERR_WINDOWS_ERROR);

            FileOffset += CommentLength;
        }
    }

    //=======================================================================
    //  Copy the user data, if any.
    //=======================================================================

    if ( UserData != NULL )
    {
        if ( UserDataLength != 0 )
        {
            CaptureFile.Header.UserDataOffset = FileOffset;
            CaptureFile.Header.UserDataLength = UserDataLength;

            if (WriteFile(hFile, UserData, UserDataLength, &BytesWritten, NULL) == FALSE)
                return BHSetLastError(BHERR_WINDOWS_ERROR);
        }
    }

    //===================================================================
    //  Write the header again.
    //===================================================================

    SetFilePointer(hFile, 0, NULL, FILE_BEGIN);

    if (WriteFile(hFile, &CaptureFile, CAPTUREFILE_SIZE, &BytesWritten, NULL) == FALSE)
        return BHSetLastError(BHERR_WINDOWS_ERROR);
    

#ifdef DEBUG
        EndTime = clock();

        dprintf("Time elapsed for save = %u seconds.\r\n", (EndTime - StartTime) / 1000L);
#endif

    return BHERR_SUCCESS;
}
