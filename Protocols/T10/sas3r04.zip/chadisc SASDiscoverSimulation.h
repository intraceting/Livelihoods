// SASDiscoverSimulation.h
// updated 2008/09/02

// the maximum number of phys in an expander device 
#define MAXIMUM_EXPANDER_PHYS             256

// the maximum number of indexes per phy 
#define MAXIMUM_EXPANDER_INDEXES          256

// limit to 8 initiators for this example
#define MAXIMUM_INITIATORS                8

// defines for address frame types
#define ADDRESS_IDENTIFY_FRAME            0x00
#define ADDRESS_OPEN_FRAME                0x01

// defines for SMP frame types
#define SMP_REQUEST_FRAME                 0x40
#define SMP_RESPONSE_FRAME                0x41

// defines for SMP request functions
#define REPORT_GENERAL                    0x00
#define REPORT_MANUFACTURER_INFORMATION   0x01
#define DISCOVER                          0x10
#define REPORT_PHY_ERROR_LOG              0x11
#define REPORT_PHY_SATA                   0x12
#define REPORT_ROUTE_INFORMATION          0x13
#define CONFIGURE_ROUTE_INFORMATION       0x90
#define PHY_CONTROL                       0x91
#define PHY_TEST                          0x92

// defines for the protocol bits
#define SATA                              0x01
#define SMP                               0x02
#define STP                               0x04
#define SSP                               0x08

// defines for open responses, arbitrary values, not defined in the spec
#define OPEN_ACCEPT                          0
#define OPEN_REJECT_BAD_DESTINATION          1
#define OPEN_REJECT_RATE_NOT_SUPPORTED       2
#define OPEN_REJECT_NO_DESTINATION           3
#define OPEN_REJECT_PATHWAY_BLOCKED          4
#define OPEN_REJECT_PROTOCOL_NOT_SUPPORTED   5
#define OPEN_REJECT_RESERVE_ABANDON          6
#define OPEN_REJECT_RESERVE_CONTINUE         7
#define OPEN_REJECT_RESERVE_INITIALIZE       8
#define OPEN_REJECT_RESERVE_STOP             9
#define OPEN_REJECT_RETRY                    10
#define OPEN_REJECT_STP_RESOURCES_BUSY       11
#define OPEN_REJECT_WRONG_DESTINATION        12
#define OPEN_REJECT_WAITING_ON_BREAK         13

// definitions for discovery algorithm use
enum
{
   SAS_SIMPLE_LEVEL_DESCENT = 0,
   SAS_UNIQUE_LEVEL_DESCENT
};

enum
{
   SAS_10_COMPATIBLE = 0,
   SAS_11_COMPATIBLE
};

// definitions for SMP function results
enum SMPFunctionResult
{
   SMP_REQUEST_ACCEPTED = 0,           // from original example

   SMP_FUNCTION_ACCEPTED = 0,
   SMP_UNKNOWN_FUNCTION,
   SMP_FUNCTION_FAILED,
   SMP_INVALID_REQUEST_FRAME_LENGTH,
   SMP_PHY_DOES_NOT_EXIST = 0x10,
   SMP_INDEX_DOES_NOT_EXIST,
   SMP_PHY_DOES_NOT_SUPPORT_SATA,
   SMP_UNKNOWN_PHY_OPERATION,
   SMP_UNKNOWN_PHY_TEST_FUNCTION,
   SMP_UNKNOWN_PHY_TEST_FUNCTION_IN_PROGRESS,
   SMP_PHY_VACANT
};

// DeviceTypes
enum DeviceTypes
{
   NO_DEVICE = 0,
   END_DEVICE,
   EXPANDER_DEVICE,
   OBSOLETE_EXPANDER_DEVICE,

   END = END_DEVICE,                   // from original example
   EXPANDER = EXPANDER_DEVICE,         // from original example
   OBSOLETE = OBSOLETE_EXPANDER_DEVICE // from original example
};

// RoutingAttribute
enum RoutingAttribute
{
   DIRECT = 0,
   SUBTRACTIVE,
   TABLE,

   // this attribute is a psuedo attribute, used to reflect the function
   // result of SMP_PHY_VACANT in a fabricated discover response
   PHY_NOT_USED = 15
};

// ConnectorType
enum ConnectorType
{
   UNKNOWN_CONNECTOR = 0,
   SFF_8470_EXTERNAL_WIDE,
   SFF_8484_INTERNAL_WIDE = 16,
   SFF_8482_BACKPLANE = 32,
   SATA_HOST_PLUG,
   SAS_DEVICE_PLUG,
   SATA_DEVICE_PLUG
};

// RouteFlag
enum DisableRouteEntry
{
   ENABLED = 0,
   DISABLED
};

// PhyLinkRate(s)
enum PhysicalLinkRate
{
   RATE_UNKNOWN = 0,
   PHY_DISABLED,
   PHY_FAILED,
   SPINUP_HOLD_OOB,
   PORT_SELECTOR_DETECTED,

   // this is a psuedo link rate, used to reflect the function
   // result of SMP_PHY_VACANT in a fabricated discover response
   PHY_DOES_NOT_EXIST,

   GBPS_1_5 = 8,
   GBPS_3_0
};

// PhyOperation
enum PhyOperation
{
   NOP = 0,
   LINK_RESET,
   HARD_RESET,
   DISABLE,
   CLEAR_ERROR_LOG = 5,
   CLEAR_AFFILIATION,
   TRANSMIT_SATA_PORT_SELECTION_SIGNAL
};

// provide the simple type definitions
typedef unsigned char byte;
typedef unsigned short word;
typedef unsigned long dword;
typedef unsigned _int64 quadword;

// the structures assume a char bitfield is valid, this is compiler 
// dependent defines would be more portable, but less descriptive

// the Identify frame is exchanged following OOB, for this
// code it contains the identity information for the attached device
// and the initiator application client
struct Identify
{
   // byte 0
   byte AddressFrameType:4;            // ADDRESS_IDENTIFY_FRAME
   byte DeviceType:3;                  // END_DEVICE
                                       //
   byte RestrictedByte0Bit7:1;

   // byte 1
   byte RestrictedByte1;

   // byte 2
   union
   {
      struct
      {
         byte RestrictedByte2Bit0:1;
         byte SMPInitiatorPort:1;
         byte STPInitiatorPort:1;
         byte SSPInitiatorPort:1;
         byte ReservedByte2Bit4_7:4;
      };
      byte InitiatorBits;
   };

   // byte 3
   union
   {
      struct
      {
         byte RestrictedByte3Bit0:1;
         byte SMPTargetPort:1;
         byte STPTargetPort:1;
         byte SSPTargetPort:1;
         byte ReservedByte3Bit4_7:4;
      };
      byte TargetBits;
   };

   // byte 4-11
   byte RestrictedByte4_11[8];

   // byte 12-19
   quadword SASAddress;

   // byte 20
   byte PhyIdentifier;

   // byte 21-27
   byte ReservedByte21_27[4];

   // byte 28-31
   dword CRC;
}; // struct Identify

// the Open address frame is used to send open requests
struct OpenAddress
{
   // byte 0
   byte AddressFrameType:4;            // ADDRESS_OPEN_FRAME
   byte Protocol:3;                    // SMP 
                                       // STP
                                       // SSP
   byte InitiatorPort:1;

   // byte 1
   byte ConnectionRate:4;              // GBPS_1_5
                                       // GBPS_3_0
   byte Features:4;

   // byte 2-3
   word InitiatorConnectionTag;

   // byte 4-11
   quadword DestinationSASAddress;

   // byte 12-19
   quadword SourceSASAddress;

   // byte 20
   byte CompatibleFeatures;

   // byte 21
   byte PathwayBlockedCount;

   // byte 22-23
   word ArbitrationWaitTime;

   // byte 24-27
   byte MoreCompatibleFeatures[4];

   // byte 28-31
   dword CRC[4];
}; // struct OpenAddress

// request specific bytes for a general input function
struct SMPRequestGeneralInput
{
   // byte 4-7
   dword CRC;
};

// request specific bytes for a phy input function
struct SMPRequestPhyInput
{
   // byte 4-7
   byte IgnoredByte4_7[4];

   // byte 8
   byte ReservedByte8;

   // byte 9
   byte PhyIdentifier;

   // byte 10
   byte IgnoredByte10;

   // byte 11
   byte ReservedByte11;

   // byte 12-15
   dword CRC;
}; // struct SMPRequestPhyInput

// the ConfigureRouteInformation structure is used to provide the
// expander route entry for the expander route table, it is intended
// to be referenced by the SMPRequestConfigureRouteInformation struct
struct ConfigureRouteInformation
{
   // byte 12
   byte IgnoredByte12Bit0_6:7;
   byte DisableRouteEntry:1;     // if a routing error is detected
                                 // then the route is disabled by
                                 // setting this bit

   // byte 13-15
   byte IgnoredByte13_15[3];

   // byte 16-23
   quadword RoutedSASAddress;    // identical to the AttachedSASAddress
                                 // found through discovery

   // byte 24-35
   byte IgnoredByte24_35[12];

   // byte 36-39
   byte ReservedByte36_39[4];
}; // struct ConfigureRouteInformation
   
// request specific bytes for SMP ConfigureRouteInformation function
struct SMPRequestConfigureRouteInformation
{
   // byte 4-5
   byte ReservedByte4_5[2];

   // byte 6-7
   word ExpanderRouteIndex;

   // byte 8
   byte ReservedByte8;

   // byte 9
   byte PhyIdentifier;

   // byte 10-11
   byte ReservedByte10_11[2];

   // byte 12-39
   struct ConfigureRouteInformation Configure;

   // byte 40-43
   dword CRC;
}; // struct SMPRequestConfigureRouteInformation

// the PhyControlInformation structure is used to provide the
// expander phy control values, it is intended
// to be referenced by the SMPRequestPhyControl struct
struct PhyControlInformation
{
   // byte 12-31
   byte IgnoredByte12_31[20];

   // byte 32
   byte IgnoredByte32Bit0_3:4;
   byte ProgrammedMinimumPhysicalLinkRate:4;

   // byte 33
   byte IgnoredByte33Bit0_3:4;             
   byte ProgrammedMaximumPhysicalLinkRate:4;

   // byte 34-35
   byte IgnoredByte34_35[2];

   // byte 36
   byte PartialPathwayTimeoutValue:4;             
   byte ReservedByte36Bit4_7:4;

   // byte 37-39
   byte ReservedByte37_39[3];
}; // struct PhyControlInformation

// request specific bytes for SMP Phy Control function
struct SMPRequestPhyControl
{
   // byte 4-7
   byte IgnoredByte4_7[4];

   // byte 8
   byte ReservedByte8;

   // byte 9
   byte PhyIdentifier;

   // byte 10
   byte PhyOperation;

   // byte 11
   byte UpdatePartialPathwayTimeoutValue:1;
   byte ReservedByte11Bit1_7:7;

   // byte 12-39
   struct PhyControlInformation Control;

   // byte 40-43
   dword CRC;
}; // struct SMPRequestPhyControl

// request specific bytes for SMP Phy Test function
struct SMPRequestPhyTest
{
   // byte 4-7
   byte IgnoredByte4_7[4];

   // byte 8
   byte ReservedByte8;

   // byte 9
   byte PhyIdentifier;

   // byte 10
   byte PhyTestFunction;

   // byte 11
   byte PhyTestPattern;

   // byte 12-14
   byte ReservedByte12_14[3];

   // byte 15
   byte PhyTestPatternPhysicalLinkRate:4;
   byte ReservedByte15Bit4_7:4;

   // byte 16-39
   byte ReservedByte16_39[24];

   // byte 40-43
   dword CRC;
}; // struct SMPRequestPhyTest

// generic structure referencing an SMP Request, must be initialized
// before being used
struct SMPRequest
{
   // byte 0
   byte SMPFrameType;                  // always SMP_REQUEST_FRAME

   // byte 1
   byte Function;                      // REPORT_GENERAL
                                       // REPORT_MANUFACTURER_INFORMATION
                                       // DISCOVER                       
                                       // REPORT_PHY_ERROR_LOG           
                                       // REPORT_PHY_SATA                
                                       // REPORT_ROUTE_INFORMATION       
                                       // CONFIGURE_ROUTE_INFORMATION    
                                       // PHY_CONTROL
                                       // PHY_TEST

   // byte 2-3
   byte ReservedByte2_3[2];

   // bytes 4-n
   union
   {
      struct SMPRequestGeneralInput ReportGeneral;
      struct SMPRequestGeneralInput ReportManufacturerInformation;
      struct SMPRequestPhyInput Discover;
      struct SMPRequestPhyInput ReportPhyErrorLog;
      struct SMPRequestPhyInput ReportPhySATA;
      struct SMPRequestPhyInput ReportRouteInformation;
      struct SMPRequestConfigureRouteInformation ConfigureRouteInformation;
      struct SMPRequestPhyControl PhyControl;
      struct SMPRequestPhyTest PhyTest;
   } Request;
}; // struct SMPRequest

// request specific bytes for SMP Report General response, intended to be
// referenced by SMPResponse
struct SMPResponseReportGeneral
{
   // byte 4-5
   word ExpanderChangeCount;

   // byte 6-7
   word ExpanderRouteIndexes;

   // byte 8
   byte ReservedByte8;

   // byte 9
   byte NumberOfPhys;

   // byte 10
   byte ConfigurableRouteTable:1;
   byte Configuring:1;
   byte ReservedByte10Bit2_7:6;

   // byte 11
   byte ReservedByte11;

   // byte 12-19
   byte EnclosureLogicalIdentifier[8];

   // byte 20-27
   byte ReservedByte20_27[8];

   // byte 28-31
   dword CRC;
}; // struct SMPResponseReportGeneral

struct SAS11FormatReportManufacturerInformation
{
   // byte 40-47
   byte ComponentVendorIdentification[8];

   // byte 48-49
   byte ComponentID[2];

   // byte 50
   byte ComponentRevisionID;

   // byte 51
   byte Reserved;

   // byte 52-59
   byte VendorSpecific[8];
}; // struct SAS11FormatReportManufacturerInformation

// request specific bytes for SMP Report Manufacturer Information response, 
// intended to be referenced by SMPResponse
struct SMPResponseReportManufacturerInformation
{
   // byte 4-7
   byte IgnoredByte4_7[4];

   // byte 8
   byte SAS11Format:1;
   byte ReservedByte8_Bit1_7:7;

   // byte 9-10
   byte IgnoredByte9_10[2];

   // byte 11
   byte ReservedByte11;

   // byte 12-19
   byte VendorIdentification[8];

   // byte 20-35
   byte ProductIdentification[16];

   // byte 36-39
   byte ProductRevisionLevel[4];

   union
   {
      struct SAS11FormatReportManufacturerInformation SAS11;

      // byte 40-59
      byte VendorSpecific[20];
   };

   // byte 60-63
   dword CRC;
}; // struct SMPResponseReportManufacturerInformation

// the Discover structure is used to retrieve expander port information
// it is intended to be referenced by the SMPResponseDiscover structure
struct Discover
{
   // byte 12
   byte ReservedByte12Bit0_3:4;
   byte AttachedDeviceType:3;   
   byte IgnoredByte12Bit7:1;

   // byte 13
   byte NegotiatedPhysicalLinkRate:4;
   byte ReservedByte13Bit4_7:4;

   // byte 14
   union
   {
      struct
      {
         byte AttachedSATAHost:1;
         byte AttachedSMPInitiator:1;
         byte AttachedSTPInitiator:1;
         byte AttachedSSPInitiator:1;
         byte ReservedByte14Bit4_7:4;
      };
      byte InitiatorBits;
   };

   // byte 15
   union
   {
      struct
      {
         byte AttachedSATADevice:1;
         byte AttachedSMPTarget:1;
         byte AttachedSTPTarget:1;
         byte AttachedSSPTarget:1;
         byte ReservedByte15Bit4_6:3;
         byte AttachedSATAPortSelector:1;
      };
      byte TargetBits;
   };

   // byte 16-23
   quadword SASAddress;

   // byte 24-31
   quadword AttachedSASAddress;

   // byte 32
   byte AttachedPhyIdentifier;

   // byte 33-39
   byte ReservedByte33_39[7];

   // byte 40
   byte HardwareMinimumPhysicalLinkRate:4;             
   byte ProgrammedMinimumPhysicalLinkRate:4;

   // byte 41
   byte HardwareMaximumPhysicalLinkRate:4;             
   byte ProgrammedMaximumPhysicalLinkRate:4;

   // byte 42
   byte PhyChangeCount;

   // byte 43
   byte PartialPathwayTimeoutValue:4;
   byte IgnoredByte36Bit4_6:3;
   byte VirtualPhy:1;

   // byte 44
   byte RoutingAttribute:4;
   byte ReservedByte44Bit4_7:4;

   // byte 45
   byte ConnectorType:7;
   byte ReservedByte45Bit7:1;

   // byte 46
   byte ConnectorElementIndex;

   // byte 47
   byte ConnectorPhysicalLink;

   // byte 48-49
   byte ReservedByte48_49[2];

   // byte 50-51
   byte VendorSpecific[2];

   // byte 52-55
   dword CRC;
}; // struct Discover
   
// response specific bytes for SMP Discover, intended to be referenced by
// SMPResponse
struct SMPResponseDiscover
{
   // byte 4-7
   byte IgnoredByte4_7;

   // byte 8
   byte ReservedByte8;

   // byte 9
   byte PhyIdentifier;

   // byte 10
   byte IgnoredByte10;

   // byte 11
   byte ReservedByte11;

   union                            // original example used Results instead
                                    // of Result, this allows both
   {
      // byte 12-55
      struct Discover Results;
      struct Discover Result;
   };
}; // struct SMPResponseDiscover

// response specific bytes for SMP Report Phy Error Log, intended to be 
// referenced by SMPResponse
struct SMPResponseReportPhyErrorLog
{
   // byte 4-7
   byte IgnoredByte4_7;

   // byte 8
   byte ReservedByte8;

   // byte 9
   byte PhyIdentifier;

   // byte 10
   byte IgnoredByte10;

   // byte 11
   byte ReservedByte11;

   // byte 12-15
   dword InvalidDwordCount;

   // byte 16-19
   dword DisparityErrorCount;

   // byte 20-23
   dword LossOfDwordSynchronizationCount;

   // byte 24-27
   dword PhyResetProblemCount;

   // byte 28-31
   dword CRC;
}; // struct SMPResponseReportPhyErrorLog

// this structure describes the Register Device to Host FIS defined in the
// SATA specification
struct RegisterDeviceToHostFIS
{
   // byte 24
   byte FISType;

   // byte 25
   byte ReservedByte25Bit0_5:6;
   byte Interrupt:1;
   byte ReservedByte25Bit7:1;

   // byte 26
   byte Status;
  
   // byte 27
   byte Error;

   // byte 28
   byte SectorNumber;

   // byte 29
   byte CylLow;

   // byte 30
   byte CylHigh;

   // byte 31
   byte  DevHead;

   // byte 32
   byte SectorNumberExp;

   // byte 33
   byte CylLowExp;

   // byte 34
   byte CylHighExp;

   // byte 35
   byte ReservedByte35;

   // byte 36
   byte SectorCount;

   // byte 37
   byte SectorCountExp;

   // byte 38-43
   byte ReservedByte38_43[6];
}; // struct RegisterDeviceToHostFIS

// response specific bytes for SMP Report Phy SATA, intended to be 
// referenced by SMPResponse
struct SMPResponseReportPhySATA
{
   // byte 4-7
   byte IgnoredByte4_7;

   // byte 8
   byte ReservedByte8;

   // byte 9
   byte PhyIdentifier;

   // byte 10
   byte IgnoredByte10;

   // byte 11
   byte AffiliationValid:1;
   byte AffiliationsSupported:1;
   byte ReservedByte11Bit2_7:6;

   // byte 12-15
   byte ReservedByte12_15[4];

   // byte 16-32
   quadword STPSASAddress;

   // byte 24-43
   struct RegisterDeviceToHostFIS FIS;

   // byte 44-47
   byte ReservedByte44_47[4];

   // byte 48-55
   quadword AffiliatedSTPInitiatorSASAddress;

   // byte 56-59
   dword CRC;
}; // struct SMPResponseReportPhySATA

struct ReportRouteInformation
{
   // byte 12
   byte IgnoredByte12Bit0_6:7;
   byte ExpanderRouteEntryDisabled:1;

   // byte 13-15
   byte IgnoredByte13_15[3];

   // byte 16-23
   quadword RoutedSASAddress;

   // byte 24-35
   byte IgnoredByte24_35[12];

   // byte 36-39
   byte ReservedByte36_39[4];
}; // struct ReportRouteInformation
   
// response specific bytes for SMP Report Route Information, intended to be 
// referenced by SMPResponse
struct SMPResponseReportRouteInformation
{
   // byte 4-5
   byte IgnoredByte4_5;

   // byte 6-7
   word ExpanderRouteIndex;

   // byte 8
   byte ReservedByte8;

   // byte 9
   byte PhyIdentifier;

   // byte 10
   byte IgnoredByte10;

   // byte 11
   byte ReservedByte11;

   // byte 12-39
   struct ReportRouteInformation Result;

   // byte 40-43
   dword CRC;
}; // struct SMPResponseReportRouteInformation

// response specific bytes for SMP Configure Route Information, 
// intended to be referenced by SMPResponse
struct SMPResponseConfigureRouteInformation
{
   // byte 4-7
   dword CRC;
};

// response specific bytes for SMP Phy Control, 
// intended to be referenced by SMPResponse
struct SMPResponsePhyControl
{
   // byte 4-7
   dword CRC;
};

// response specific bytes for SMP Phy Test, 
// intended to be referenced by SMPResponse
struct SMPResponsePhyTest
{
   // byte 4-7
   dword CRC;
};

// generic structure referencing an SMP Response, must be initialized
// before being used
struct SMPResponse
{
   // byte 0
   byte SMPFrameType;                  // always 41h for SMP responses

   // byte 1
   byte Function;

   // byte 2
   byte FunctionResult;

   // byte 3
   byte ReservedByte3;

   // bytes 4-n
   union
   {
      struct SMPResponseReportGeneral ReportGeneral;
      struct SMPResponseReportManufacturerInformation 
             ReportManufacturerInformation;
      struct SMPResponseDiscover Discover;
      struct SMPResponseReportPhyErrorLog ReportPhyErrorLog;
      struct SMPResponseReportPhySATA ReportPhySATA;
      struct SMPResponseReportRouteInformation ReportRouteInformation;
      struct SMPResponseConfigureRouteInformation ConfigureRouteInformation;
      struct SMPResponsePhyControl PhyControl;
      struct SMPResponsePhyTest PhyTest;
   } Response;
}; // struct SMPResponse

// this structure is how this simulation obtains its knowledge about the
// initiator port that is doing the discover, it is not defined as part of
// the standard...
struct ApplicationClientKnowledge
{
   quadword SASAddress;
   byte NumberOfPhys;
   byte InitiatorBits;
   byte TargetBits;
};

// the RouteTableEntry structure is used to contain the internal copy of
// the expander route table
struct RouteTableEntry
{
   byte ExpanderRouteEntryDisabled;
   quadword RoutedSASAddress;
};

// the TopologyTable structure is the summary of the information gathered
// during the discover process, the table presented here is not concerned 
// about memory resources consumed, production code would be more concerned 
// about specifying necessary elements explictly
struct TopologyTable
{
   // pointer to a simple list of expanders in topology
   // a walk through this link will encounter all expanders in 
   // discover order
   struct TopologyTable *Next;

   // simple reference to this device, primarily to keep identification of
   // this structure simple, otherwise, the only place the address is
   // located is within the Phy element
   quadword SASAddress;

   // information from REPORT_GENERAL
   struct SMPResponseReportGeneral Device;

   // information from DISCOVER
   struct SMPResponseDiscover Phy[MAXIMUM_EXPANDER_PHYS];

   // list of route indexes for each phy
   word RouteIndex[MAXIMUM_EXPANDER_PHYS];

   // internal copy of the route table for the expander
   struct RouteTableEntry 
          RouteTable[MAXIMUM_EXPANDER_PHYS][MAXIMUM_EXPANDER_INDEXES];

   //
   // in production code there would also be links to the necessary device 
   // information like end device; vendor, model, serial number, etc.
   // the gathering of that type of information is not done here...
   //
}; // struct TopologyTable
