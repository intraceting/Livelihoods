from numpy import *
from pylab import *

# version 071210.a

def extractJitter(inputT, outputsignalF, signalF, offset, RJ, timestep, mylength) :

	# the offset parameter will eventually be automatically calculated
	
	from scipy.special import erfinv
	from penrose import extractApproxEdge,extractAccurateEdge,extractAccurateEdge
	from cdr import cdr
	import pdb

	_inputT = extractApproxEdge(inputT)
	_outputsignalF = extractAccurateEdge(outputsignalF)
	_signalF = extractAccurateEdge(signalF)
	
	j = array(_inputT)[offset:len(_outputsignalF)+offset] - ( array(_outputsignalF) - array(_signalF)[offset:len(_outputsignalF)+offset] )

	# extract the noise inbetween two edges
	# this could be improved!!
	noise = []
	for i in range(len(_outputsignalF)-1) :
		noise += [ signalF[ int( (_signalF[offset+i]+_signalF[offset+i+1])/2.0 ) ] - outputsignalF[ int( (_outputsignalF[i]+_outputsignalF[i+1])/2.0 ) ] ]


	figure()
	hold(0)
	plot(noise)
	grid(1)
	xlabel('time [sample #]')
	ylabel('amplitude [V]')
	title('Transmitter Noise')
	savefig('noise.png')

	outtime  = arange(len(noise)) * timestep
	outfile = open('noise.csv','w')
	for index in range(len(outtime)) :
		outfile.writelines('%e,%e\n'%(outtime[index],noise[index]))
	outfile.close()

	if 0:
		figure()
		hold(0)
		plot(_inputT,'x')
		hold(1)
		plot(_outputsignalF,'x')
		plot(_signalF,'x')
		plot(j,'o')
		grid(1)
	
	[pe,per]=cdr(j,0.005,0.005,'CDR Jitter Extraction')
	
	_per = mean(per[1000:])
	[pdf,t]=histogram(array(pe[1000:])/_per,100)

	# pdb.set_trace()

	pdf[find(pdf<5)] = 0 
	pdf = pdf*1.0 / sum(pdf)
	mid = min(find(t>0))
	left = max(find(pdf[:mid] == 0)) + 1
	rght = min(find(pdf[mid:] == 0)) - 1 + mid 
	
	leftcdf = cumsum(pdf[left:mid])
	leftcdf[find(leftcdf==1)] = 1-1e-15
	rghtcdf = flipud(cumsum(flipud(pdf[mid:rght])))
	rghtcdf[find(rghtcdf==1)] = 1-1e-15

	leftt = t[left:mid]
	rghtt = t[mid:rght]
	
	Qleft = -sqrt(2) * erfinv( 2.0 * (1 - leftcdf) -1 )
	Qrght = -sqrt(2) * erfinv( 2.0 * (1 - rghtcdf) -1 )
	
	npoints = 4
	# Pleft = polyfit(leftt[0:npoints],Qleft[0:npoints],1)
	# Prght = polyfit(rghtt[-npoints:],Qrght[-npoints:],1)
	
	_Qleft = concatenate(( [-7] , Qleft ))
	_Qrght = concatenate(( Qrght , [-7] ))
	
	# _RJ = ( 1.0 / abs(Pleft[0]) + 1.0 / abs(Prght[0]) ) / 2.0
	DJ = -Qrght[-1] * RJ - Qleft[0] * RJ 

	_leftt = concatenate(( [ leftt[0] - (Qleft[0]+7)*RJ ] , leftt ))
	_rghtt = concatenate(( rghtt , [ rghtt[-1] + (Qrght[-1]+7)*RJ ] ))

	print 'Extracted RJ = %0.4f, DJ = %0.4f'%(RJ, DJ)

	figure()
	hold(0)
	plot(_leftt,_Qleft)
	hold(1)
	plot(_rghtt,_Qrght)
	grid(1)
	xlabel('Time [UI]')
	ylabel('Q')
	title('Extracted Transmit Jitter, RJ = %0.4f, DJ = %0.4f'%(RJ, DJ) )
	savefig('ExtractedJitter.png')
	
	return([RJ,DJ])	

