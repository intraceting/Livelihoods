from analysis import *
from numpy import *
import numpy
from pylab import *
import time
from string import rsplit, rstrip
from scipy import linalg, interp
from re import *
import pdb

# version 080110.a

def extractApproxEdge(x) :
	y = find( abs(diff( (array(x)>0)*1.0 )) == 1.0 )
	return(y)


def extractAccurateEdge(x) :
	from scipy import interp
	y = []
	for i in range(len(x)-1) :
		if ( ((x[i] < 0.0) and (x[i+1] > 0.0)) or ((x[i] > 0.0) and (x[i+1] < 0.0)) ) :
			_y = interp([0],[x[i],x[i+1]],[i,i+1])[0]
			y += [_y]
	return(y)

def filter(x,k) :
	y = [x[0]]
	for _x in x:
		y += [ (_x-y[-1])*k + y[-1] ]
	return(y)

def buildM(x,l) :
	M = []
	for i in range(len(x)-l) :
		M += [ x[i:i+l] ] 
	return(M)


def penrose(filename, mylength,start,finish,timecol,sigcol) :
	#mylength 	= 800
	#start 		= 37000
	#finish		= 41000
	signalFilter	= 0.90
	stimFilter	= 0.90
	outputFilter	= 0.90
	
	
	[time,signal]=loadcsv(filename,start,finish,timecol,sigcol)
	start = (array(signal)<0).nonzero()[0][0]
	end = (array(signal)>0).nonzero()[0][-1]
	
	print 'Signal analysis from %d to %d'%(start,end)
	
	signalF 	= filter(signal,signalFilter)
	signalF 	= signalF[start:end+1]
	inputT 		= (array(signalF)>0)*2.0-1.0
	inputF 		= filter(inputT,stimFilter)
	M_inputF 	= buildM(inputF,mylength)
	IM_inputF 	= linalg.pinv(transpose(M_inputF))
	taps 		= matrixmultiply(transpose(IM_inputF),(signalF[mylength/2:mylength/2 + len(IM_inputF)]))
	outputsignal	= matrixmultiply(M_inputF,taps)
	outputsignalF 	= filter(outputsignal,outputFilter)
	
	testT 			= ones(mylength*10)*-1.0
	testT[mylength*5:]	= 1.0
	testF			= filter(testT,stimFilter)
	M_testF			= buildM(testF,mylength)
	outputtest		= matrixmultiply(M_testF,taps)
	outputtestF		= filter(outputtest,outputFilter)

#	figure()
#	hold(0)
#	plot(taps)
#	grid(1)
#	xlabel('time [sample #]')
#	ylabel('amplitude [V]')
#	savefig('taps.png')

	figure()
	llength = 10000
	hold(0)
	plot(signalF[mylength/2-1:llength])
	hold(1)
	plot(inputF[mylength/2-1:llength])
	plot(outputsignalF[:llength])
	grid(1)
	xlabel('time [sample #]')
	ylabel('amplitude [V]')
	legend(['Measured Signal', 'Fundamental Transmitter', 'Reconstructed'])
	title('Signal Reconstruction')
	axis([axis()[1]/2,axis()[1]/2+1000,axis()[2],axis()[3]])
	savefig('inAndOutSignal.png')
	
	figure()
	hold(0)
	plot(outputtestF)
	grid(1)
	xlabel('time [sample #]')
	ylabel('amplitude [V]')
	#axis([4900,5100,axis()[2],axis()[3]])
	title('Extracted Step Response')
	savefig('step.png')
	
	outtime  = arange(len(outputtestF)) * (time[1]-time[0])
	outfile = open('extractedStep.csv','w')
	for index in range(len(outtime)) :
		outfile.writelines('%e,%e\n'%(outtime[index],outputtestF[index]))
	outfile.close()

	return([inputT, outputsignalF, signalF, time[1]-time[0]]) 

