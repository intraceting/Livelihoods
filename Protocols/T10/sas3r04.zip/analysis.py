from string import rstrip
from re import split, search

version = "071210.a"

def loadcsv(filename,startline,endline,timecol,sigcol) :
	time = []
	signal = []
	_line = 0
	flag = 0

	for line in file('%s.csv'%filename) :
		if flag == 0:
			if search('^[0-9,]',line) :
				flag = 1

		if flag == 1:
			_line += 1
			if (_line > endline) and (endline>0) :
				break
			if _line > startline :
				line = rstrip(line)
				a = split(',',line)
				_time = eval(a[timecol])
				_signal = eval(a[sigcol])
				time += [_time]
				signal += [_signal]

	return([time,signal])

def loadtxt(filename,startline,endline,timecol,sigcol) :
	time = []
	signal = []
	_line = 0
	flag = 0

	for line in file('%s.txt'%filename) :
		if flag == 0:
			if search('^[0-9,]',line) :
				flag = 1

		if flag == 1:
			_line += 1
			if (_line > endline) and (endline>0) :
				break
			if _line > startline :
				line = rstrip(line)
				a = split(' ',line)
				_time = eval(a[timecol])
				_signal = eval(a[sigcol])
				time += [_time]
				signal += [_signal]

	return([time,signal])


def polar2rect(r, w, deg=0):		# radian if deg=0; degree if deg=1
    from math import cos, sin, pi
    if deg:
	w = pi * w / 180.0
    return [r * cos(w), r * sin(w)]

def rect2polar(x, y, deg=0):		# radian if deg=0; degree if deg=1
    from math import hypot, atan2, pi
    if deg:
	return hypot(x, y), 180.0 * atan2(y, x) / pi
    else:
	return [hypot(x, y), atan2(y, x)]

