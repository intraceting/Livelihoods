import fnmatch
import os
import subprocess
import string
import sys
 
pythonPath = "c:/program files/python25/python.exe"   # or "c:/python25/python.exe"
rootPath = string.replace(string.rstrip(os.popen('cd').readlines()[0]),'\\','/')
#rootPath = 'c:/pub/stateye/v5.080111'  # location of the .s4p files, if the current directory is not the one

# run simulations with all combinations of the following
sparmfiles = [ '*.s4p']  # s4p filename(s), honors UNIX shell-style wildcards
amps = [ '0.850' ] # TxNorm amplitude settings
deemps = [ '2', '3', '4' ]  # deemphasis settings
dfetaps = [ '3' ]  # dfetaps settings
# Changed default coding to '8'=8b10b document 10-007r0 on December 9, 2009
codings = [ '8'  ]  # scrambled settings '8'=8b10b, 'r'=random
rates = [ '6.0e9' ] # physical link rates (bits per second)

# FIXFIX add a linux equivalent, parsing /proc/cpuinfo
numprocs = int(os.getenv('NUMBER_OF_PROCESSORS'));
print "%d processors available"%numprocs;
# use at least 1 process, but leave 1 processor free if multiple are available
if (numprocs == 0):
    numprocs = 1;
    numprocs = 1;
if (numprocs > 2):
    numprocs = numprocs - 1;
if (numprocs > 3):
    print "code changes needed in testall.py needed to support more than 3 subprocesses";
    numprocs = 3;
print "using %d subprocesses"%numprocs;
procslot = 0;

print "Running Stateye"
for sparmfile in sparmfiles:
    for root, dirs, files in os.walk(rootPath):
        for filename in files:
            if fnmatch.fnmatch(filename, sparmfile):
                for coding in codings:
                    for amp in amps:
                        for deemp in deemps:
                            for dfetap in dfetaps:
                                for rate in rates:
                                    cmd = [\
                                        pythonPath,\
                                        "testcase.py",\
                                        "-s", os.path.join(root, filename),\
                                        "-a", amp,\
                                        "-d", deemp,\
                                        "-t", dfetap,\
                                        "-c", coding,\
                                        "-b", rate\
                                        ]
                                    print "Running testcase.py -s %s -a %s -d %s -t %s -c %s -b %s"%(filename, amp, deemp, dfetap, coding, rate)
                                    #retcode = subprocess.call(cmd)
                                    # FIXFIX can python handle an array of objects? workaround for now...
                                    if (procslot == 0):
                                        p0 = subprocess.Popen (cmd);
                                    elif (procslot == 1):
                                        p1 = subprocess.Popen (cmd);
                                    elif (procslot == 2):
                                        p2 = subprocess.Popen (cmd);
                                        
                                    procslot = procslot + 1;

                                    if (procslot == numprocs):
                                        print "Waiting for 3 completions"
                                        retcode0 = p0.wait();
                                        retcode1 = p1.wait();
                                        retcode2 = p2.wait();
                                        procslot = 0;
                                        print "Completed 3 with retcode=%d %d %d"%(retcode0, retcode1, retcode2)

# if any jobs are left over, wait for completion
if (procslot == 2):
    print "Waiting for 2 completions"
    retcode0 = p0.wait();
    retcode1 = p1.wait();
    print "Completed 2 with retcode=%d %d"%(retcode0, retcode1)
elif (procslot == 1):
    print "Waiting for 1 completion"
    retcode0 = p0.wait();
    print "Completed 1 with retcode=%d"%retcode0

print "Stateye done"
