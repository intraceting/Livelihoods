% MATLAB (R) script to compute TWDP, WDP, and NC-DDJ %%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Version: 1.9
% Date: September 11, 2009
%
% � 2004, 2005, 2006, 2007, 2008, 2009 ClariPhy Communications, Inc. and 
% LSI Corporation. All rights reserved. 
% Permission is hereby granted to the ANSI INCITS standards body to copy and 
% distribute this code in source and binary form, as necessary to publish the 
% standard, namely the ANSI INCITS SAS-2.1 standard, to which this source or 
% binary code applies provided that the following conditions are met: 
% Redistribution of source code must retain the above copyright notice, this 
% list of conditions and the following disclaimer. 
% Redistributions in binary form must retain the above copyright notice, this 
% list of conditions and the following disclaimer in the documentation and/or 
% other materials provided with the distribution. 
% The names of ClariPhy Communications, Inc., LSI Corporation and the names of 
% individual authors or contributors may NOT be used to endorse or promote 
% products derived from this software without specific prior written permission. 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS �AS IS� 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. NO WARRANTY OF NON-INFRINGEMENT OF ANY PATENT IS PROVIDED. 
% IN NO EVENT SHALL THE COPYRIGHT OWNER(S) OR CONTRIBUTORS BE LIABLE FOR ANY 
% DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
% (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
% LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
% ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
% (INCLUDING INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS, NEGLIGENCE OR 
% OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
% ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. THE LICENSE GRANTED HEREIN IS TO 
% THE COPYRIGHT ON THE SOURCE AND BINARY FORMS OF THIS CODE ONLY AND DOES NOT 
% INCLUDE A LICENSE TO ANY PATENT RIGHTS, OWNED BY THE COPYRIGHT HOLDERS, 
% CONTRIBUTORS OR OTHERS, WHICH MAY BE IMPLICATED BY THE MAKING, USING, 
% SELLING, OFFERING FOR SALE OR IMPORTING OF THE SOFTWARE OR PRODUCTS MAKING 
% USE OF THE SOFTWARE. 
% 
% Based on original TWDP methodology described in IEEE Std 802.3aq(TM)-2006
%
% Reference: N. L. Swenson, P. Voois, T. Lindsay, and S. Zeng, "Standards
% compliance testing of optical transmitters using a software-based equalizing
% reference receiver", paper NWC3, Optical Fiber Communication Conference and
% Exposition and The National Fiber Optic Engineers Conference on CD-ROM
% (Optical Society of America, Washington, DC), Feb. 2007
%
% Syntax:
% [xWDP, ncDDJ, MeasuredxMA, yout] = SASWDP( WaveformFile, TxDataFile, ...
%     SymbolRate, OverSampleRate, Usage, ShowEye )
%
% Inputs:
% -------
% WaveformFile: The waveform consists of exactly N samples per unit interval
%  T, where N is the oversampling rate. The waveform must be circularly 
%  shifted to align with the transmit data sequence. The file format is ASCII
%  with a single column of chronological numerical samples, in signal level,
%  with no headers or footers. Enter as a string.
%  This may also be entered as a row or column vector of values.
% TxDataFile: The transmit data sequence should be one of standard test 
%  patterns The file format is ASCII with a single column of chronological 
%  ones and zeros with no headers or footers. Enter as a string.
%  This may also be entered as a row or column vector of values.
% SymbolRate: The reciprocal of the unit interval in GBd. Enter as a double.
% OverSampleRate: Number of samples, N, per unit interval. Enter as a double.
% Usage: Defines the parameter set specific to the requirement to be verified.
%  In this version, the only permissible values are 'SAS2_TWDP' and 
%  'SAS2_LDP'. Enter as a string.
% ShowEye: Controls the graphical display of the slicer input eye. Any value
% greater than zero enables the display (and is the figure number for the 
% first figure generated). Enter as a double.
% 
% Outputs:
% --------
% xWDP: Waveform Dispersion Penalty (dBe)
% ncDDJ: non-compensable DDJ. This is computed from twice the worst-case eye 
%        closure and should be improved.
% MeasuredxMA: Approximative magnitude of the waveform (from 40-60% amplitude 
%              of a 5-zeros/5-ones pattern)
% yout is the result of the convolution with the channel response 
%      (for debugging purposes).
%
% This script requires the file 'sas2_stressor_6g0_16x.txt' in 
% the same directory

%% Function: SASWDP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xWDP,ncDDJ,MeasuredxMA,yout]=...
    SASWDP(WaveformFile,TxDataFile,SymbolRate,OverSampleRate,Usage,ShowEye)
%% Program constants
SymbolPeriod=1/SymbolRate;
Q0=7.94; % BER = 10^(-15)
%% Load input waveform and data sequence, generate filter and other matrices
% Accept vectors
if ischar(WaveformFile)
  yout0=load(WaveformFile);
else
  yout0=WaveformFile(:);
end
if ischar(TxDataFile)
  XmitData=load(TxDataFile);
else
  % Convert to double otherwise toeplitz may think it is logical...
  XmitData=double(TxDataFile(:));
end
%yout0=load(WaveformFile);
%XmitData=load(TxDataFile);

PtrnLength=length(XmitData);
TotLen=PtrnLength*OverSampleRate;
Fgrid=(-TotLen/2:TotLen/2-1).'/(PtrnLength*SymbolPeriod);

% MG as a first thing, convolve with channel. MeasuredxMA is unused in GetParams
[EqNf,EqNb,H_chan,AAfilter,H_r,PAlloc,dBscale,xMAGain,UseLAMP]=...
    GetParams(Usage,Fgrid,SymbolPeriod,1);

yout0=real(ifft(fft(yout0).*fftshift(H_chan)));

%% Enforce column vectors
yout0 = yout0(:);
XmitData = XmitData(:);
%% Normalize the received OMA or VMA to 1. Estimate the xMA of the captured
%% waveform by using a linear fit to estimate a pulse response, synthesize a
%% square wave, and calculate the xMA of the synthesized square wave per IEEE
%% 802.3, clause 52.9.5.
ant=4; mem=40; % Anticipation and memory parameters for linear fit
X=zeros(ant+mem+1,PtrnLength); % Size data matrix for linear fit
Y=zeros(OverSampleRate,PtrnLength); % Size observation matrix for linear fit
for ind=1:ant+mem+1 % Wrap appropriately for linear fit
    X(ind,:)=XmitData(mod((0:PtrnLength-1)-ind+ant+1,PtrnLength)+1).';
end
X=[X;ones(1,PtrnLength)]; % The all-ones row is included to compute the bias
for ind=1:OverSampleRate
    Y(ind,:)=yout0((0:PtrnLength-1)*OverSampleRate+ind)'; % 1 bit per column
end
Qmat=Y*X'*(X*X')^(-1); % Coefficient matrix resulting from linear fit. Each
%% column (except the last) is one bit period of the pulse response. The last
%% column is the bias.
SqWvPer=10; % Even number; sets the period of the sq wave used to compute xMA
SqWv=[zeros(SqWvPer/2,1);ones(SqWvPer/2,1)]; % One period of sq wave (column)
X=zeros(ant+mem+1,SqWvPer); % Size data matrix for synthesis
for ind=1:ant+mem+1 % Wrap appropriately for synthesis
    X(ind,:)=SqWv(mod((0:SqWvPer-1)-ind+ant+1,SqWvPer)+1).';
end
X=[X;ones(1,SqWvPer)]; % Include the bias
Y=Qmat*X;Y=Y(:); % Synthesize the modulated square wave, put into one column
Y=AlignY(Y,SqWvPer,OverSampleRate);
avgpos=(0.4*SqWvPer/2*OverSampleRate:0.6*SqWvPer/2*OverSampleRate);
ZeroLevel=mean(Y(round(avgpos),:)); % Average over middle 20% of "zero" run
%% Average over middle 20% of "one" run, compute xMA
MeasuredxMA=mean(Y(round(SqWvPer/2*OverSampleRate+avgpos),:))-ZeroLevel;
%% Subtract zero level and normalize xMA
youtn=(yout0-ZeroLevel)/MeasuredxMA;
%% Get usage parameters for the application

%[MG] Removing the second call to GetParams
%[EqNf,EqNb,H_chan,AAfilter,H_r,PAlloc,dBscale,xMAGain,UseLAMP]=...
%    GetParams(Usage,Fgrid,SymbolPeriod,MeasuredxMA);

ONE=ones(PtrnLength,1);
%% Set search range for equalizer delay, specified in symbol periods. Lower end
%% of range is minimum channel delay less 5 for a guardband. Upper end of range
%% accounts for the FFE. Round up and add 5 to guardband for the channel and
%% antialiasing filter.
EqDelMin=-5;
EqDelMax=ceil(EqNf/2)+5;
%% Compute the minimum slicer MSE and corresponding xWDP and ncDDJ
X=toeplitz(XmitData,[XmitData(1);XmitData(end:-1:end+1-EqNb)]);
Xtil=toeplitz(XmitData(mod((0:PtrnLength-1)-EqDelMin,PtrnLength )+1),...
    XmitData(mod(-EqDelMin:-1:-(EqDelMax+EqNb),PtrnLength)+1));
Rxx=X'*X; % Used in MSE calculation
for ii=1:size(H_chan,2) % index for stressor
    %% Compute the noise autocorrelation sequence at the output of the front-end
    %% antialiasing filter and rate-2/T sampler.
    N0=SymbolPeriod/2/(Q0*10^(PAlloc(ii)/dBscale))^2;
    Snn=N0/2*fftshift(abs(H_r).^2)*1/SymbolPeriod*OverSampleRate;
    Rnn=real(ifft(Snn));
    Corr=Rnn(1:OverSampleRate/2:end);
    C=toeplitz(Corr(1:EqNf));
    % [MG] Removing convolution at this point
    yout=youtn;
%    yout=real(ifft(fft(youtn).*fftshift(H_chan(:,ii))));
    if AAfilter > 0
        %% Process signal through front-end antialiasing filter
        yout=real(ifft(fft(yout).*fftshift(H_r)));
    end
    %% Compute the sampling function and sample the processed waveform
    [yk,tk,index1]=CDRSample(yout,OverSampleRate,PtrnLength,UseLAMP);
    %% Compute MMSE-DFE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% The MMSE-DFE filter coefficients computed below minimize mean-squared
    %% error at the slicer input. The derivation follows from the fact that the
    %% slicer input over the period of the data sequence can be expressed as 
    %% Z = (R+N)*W - X*[0 B]', where R and N are Toeplitz matrices constructed 
    %% from the signal and noise components, respectively, at the sampled 
    %% output of the antialiasing filter, W is the feedforward filter, X is a
    %% Toeplitz matrix constructed from the input data sequence, and B is the
    %% feedback filter. The computed W and B minimize the mean square error 
    %% between the input to the slicer and the transmitted sequence due to
    %% residual ISI and Gaussian noise. Minimize MSE over FFE delay and 
    %% determine BER.
    Rout=toeplitz(yk,[yk(1);yk(end:-1:end-EqNf+2)]);
    R=Rout(index1:2:end,:);
    RINV=inv([R'*R+PtrnLength*C,R'*ONE;ONE'*R,PtrnLength]);
    R=[R,ONE]; % Add all-ones column to compute optimal offset
    Rxr=Xtil'*R; Px_r=Rxr*RINV*Rxr';
    %% Minimize MSE over equalizer delay
    MseOpt=Inf;
    for kk=1:EqDelMax-EqDelMin+1
        SubRange=(kk:kk+EqNb);
        SubRange=mod(SubRange-1,PtrnLength)+1;
        P=Rxx-Px_r(SubRange,SubRange);
        P00=P(1,1); P01=P(1,2:end); P11=P(2:end,2:end);
        Mse=P00-P01*inv(P11)*P01';
        if (Mse < MseOpt)
            MseOpt=Mse;
            B=-inv(P11)*P01'; % Feedback filter
            XSel=Xtil(:,SubRange);
            W=RINV*R'*XSel*[1;B]; % Feedforward filter
            Z=R*W-XSel*[0;B]; % Input to slicer
            %% Compute BER using semi-analytic method
            MseGaussian=W(1:end-1)'*C*W(1:end-1);
            Ber=mean(0.5*erfc((abs(Z-0.5)/sqrt(MseGaussian))/sqrt(2)));
        end
    end
    %% Compute equivalent SNR %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% This function computes the inverse of the Gaussian error probability
    %% function. The built-in function erfcinv() is not sensitive enough for 
    %% low probability of error cases.
    if Ber>10^(-12),Q=sqrt(2)*erfinv(1-2*Ber);
    elseif Ber>10^(-323),Q=2.1143*(-1.0658-log10(Ber)).^0.5024;
    else Q=min(abs(Z-0.5))/sqrt(MseGaussian);
    end
    %% Compute penalty and ncDDJ %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    RefSNR=dBscale*log10(Q0)+PAlloc(ii);
    xWDP(ii)=RefSNR-dBscale*log10(Q);
    xWDP(ii)=xWDP(ii)-xMAGain(ii); % Offset xWDP by the eligible xMA gain
    ncDDJ(ii)=AnalyzeEye(yout,tk,index1,W,B,XSel,MseGaussian,...
        ShowEye,Usage,ii,MeasuredxMA,Q,Q0,xWDP(ii),dBscale);
end
%% End of SASWDP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Subfunction: GetParams %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [EqNf,EqNb,H_chan,AAfilter,H_r,PAlloc,dBscale,xMAGain,UseLAMP]=...
    GetParams(Usage,Fgrid,SymbolPeriod,MeasuredxMA)
switch upper(Usage)
    case 'SAS2_TWDP'
        EqNf=1;
        EqNb=3;
        %% Import stressor response from file %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% stressorFile : Contains the stressor impulse response(s) sampled
        %% at an interval of "stressorStep". The file format is ASCII with a 
        %% column of chronological numerical samples for each stressor with 
        %% no headers or footers.
        stressorFile='sas2_stressor_6g0_16x.txt';
        stressorStep=1/(16*6.0);
        %% Resample the stressor at an interval of "SymbolPeriod/OverSampleRate"
        OverSampleRate=round(length(Fgrid)*mean(diff(Fgrid))*SymbolPeriod);
        stressor0=load(stressorFile);
        stressor0Time=(0:length(stressor0)-1)*stressorStep;
        stressorTime=(0:length(Fgrid)-1)*SymbolPeriod/OverSampleRate;
        stressor=interp1(stressor0Time,stressor0.',stressorTime,'linear',0);
        stressor=stressor*SymbolPeriod/(OverSampleRate*stressorStep);
        H_chan=fftshift(fft(stressor.'),1);        
        %% AAFilter disables anti-aliasing filter processing of the signal 
        %% under test (noise is still shaped). This parameter is used by 
        %% Fibre Channel but recommended to be set to 1 for other 
        %% applications.
        AAfilter=1;
        %% Denominator coefficients for 7.5 GHz 4-port Butterworth filter
        a=[1,123.140658357,7581.81087032,273453.656327,4931335.23359];
        AABW=0.75/SymbolPeriod;  % Scale coefficients for different bandwidth               
        sc=(AABW/7.5).^[0:4]; a=a.*sc;
        H_r=a(end)./polyval(a,j*2*pi*Fgrid);
        PAlloc=15.4;
        dBscale=20;
        xMAGain=0;
        UseLAMP=0;
        % UseLAMP=1;    
    case 'SAS2_LDP'
        EqNf=1;
        EqNb=3;       
        H_chan=1;
        %% AAFilter disables anti-aliasing filter processing of the signal 
        %% under test (noise is still shaped). This parameter is used by 
        %% Fibre Channel but recommended to be set to 1 for other 
        %% applications.
        AAfilter=1;
        %% Denominator coefficients for 7.5 GHz 4-port Butterworth filter
        a=[1,123.140658357,7581.81087032,273453.656327,4931335.23359];
        AABW=0.75/SymbolPeriod;  % Scale coefficients for different bandwidth               
        sc=(AABW/7.5).^[0:4]; a=a.*sc;
        H_r=a(end)./polyval(a,j*2*pi*Fgrid);
        PAlloc=15.4;
        dBscale=20;
        xMAGain=0;
        UseLAMP=0;
        % UseLAMP=1;
    otherwise
        error('Usage not recognized.');
end
%% End of GetParams %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Subfunction: AlignY %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Y = AlignY(Y0,SqWvPer,OverSampleRate)
%% Aligns the mid crossing of the xMA square waveform to its ideal position.
Y=Y0-mean(Y0); % AC-couple so crossings are at 0.
%% Look only for the crossing in the middle by ignoring any within ~2 UI from
%% its beginning. Due to possible misalignment of the captured waveform, this
%% is the only crossing that is certain.
%% x=find(sign(Y(2*OverSampleRate:end-1))~=...
%%     sign(Y(2*OverSampleRate+1:end)),1)+2*OverSampleRate-1;
x=min(find(sign(Y(2*OverSampleRate:end-1))~=...
    sign(Y(2*OverSampleRate+1:end))))+2*OverSampleRate-1;
%% Find a more exact crossing point.
xinterp=interp1([Y(x),Y(x+1)],[x,x+1],0);
%% Shift to create the aligned square waveform.
SqWvLen=SqWvPer*OverSampleRate;
Y=Y0(mod((0:SqWvLen-1)-SqWvLen/2+x,SqWvLen)+1); % Coarse shift.
X=(1:length(Y))';Y=interp1(X,Y,(1:length(Y))'+xinterp-x,'spline'); % Fine shift.
%% End of AlignY %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Subfunction: CDRSample %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [yk,tk,index1] = ...
    CDRSample(yout,OverSampleRate,PtrnLength,UseLAMP)
%% Derive normalized frequency grid from the input arguments
TotLen=OverSampleRate*PtrnLength;
Fgridn=(-TotLen/2:TotLen/2-1).'/PtrnLength;
%% Compute the frequency response for spectral line bandpass filter
w1=2*pi*(1-1/3000); % Define the pass band (normalized to signaling speed)
w2=2*pi*(1+1/3000);
w0=sqrt(w1*w2);
Bw=w2-w1;
% Denominator and numerator coefficients for a prototype low pass filter
ap=[1,2,1];
bp=[0,2,1];
% Apply frequency transformation to realize the desired bandpass filter
s=j*2*pi*Fgridn(find(Fgridn ~= 0));
sprime=(s.^2+w0^2)./(Bw*s);
Hp=zeros(1,TotLen);
Hp(find(Fgridn ~= 0))=polyval(bp,sprime)./polyval(ap,sprime);
%% Compute the sampling function and sample the waveform
km1=mod((0:TotLen-1)-1,TotLen)+1;
kp1=mod((0:TotLen-1)+1,TotLen)+1;
if UseLAMP > 0
    ylim=tanh(10*(yout-mean(yout)));
    yclk=real(ifft(fft(abs(ylim(kp1)-ylim(km1))).*fftshift(Hp(:))));
else
    yclk=real(ifft(fft(abs(yout(kp1)-yout(km1))).*fftshift(Hp(:))));
end
yclk=yclk(kp1)-yclk(km1);
time=(0:TotLen).'/OverSampleRate; % Wrap waveforms to ensure all edges are
yout=[yout;yout(1)];              % are detected
yclk=[yclk;yclk(1)];
yclk=yclk/(max(yclk)-min(yclk))+0.5; % Normalize clock waveform
kr=find(diff(yclk > 0.5) > 0); % Eye center index
kf=find(diff(yclk > 0.5) < 0); % Eye crossing index
k=sort([kr;kf]);
index1=double(kr(1) > kf(1))+1; % Index of the first eye center
tk=time(k)-(1/OverSampleRate)*(yclk(k)-0.5)./(yclk(k+1)-yclk(k));
yk=interp1(time,yout,tk);
%% End of CDRSample %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Subfunction: AnalyzeEye %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ncDDJ=AnalyzeEye(yout,tk,index1,W,B,XSel,MseGaussian, ...
    showEye,usage,ii,MeasuredxMA,Q,Q0,xWDP,dBscale)
%% Extract required equalizer parameters from the input arguments.
EqNf=length(W)-1; % Number of T/2-spaced feed-forward taps
EqNb=length(B); % Number of T-spaced feedback taps
xr=XSel(:, 1); % Error-free decisions
%% Define the axes of the bit error ratio map
dphi=1/100; % Phase step (unit interval)
dvee=1/200; % Eye diagram amplitude step (unit amplitude)
phiList=linspace(-0.5,0.5,round(1/dphi)+1);
veeList=linspace(-0.5,0.5,round(1/dvee)+1);
if ~(showEye > 0),veeList = 0;end
%% Compute the bit error ratio at each point in the time-amplitude grid.
PtrnLength=length(xr);
OverSampleRate=round(length(yout)/PtrnLength);
time=(0:OverSampleRate*PtrnLength).'/OverSampleRate;
yout=[yout;yout(1)];
for jj=1:length(phiList)
    phi=phiList(jj);
    yk=interp1(time,yout,mod(tk+phi,time(end)));
    Y=toeplitz(yk,[yk(1);yk(end:-1:end-EqNf+2)]);
    Y=Y(index1:2:end,:);
    Y=[Y,ones(PtrnLength,1)];
    zk=Y*W-XSel*[0; B];
    %% Compute the minimum distance from the noiseless, equalized samples
    %% to the decision threshold.
    eyeLid0(jj)=max(zk(find(xr == 0)));
    eyeLid1(jj)=min(zk(find(xr == 1)));
    %% Compute the bit error ratio as a function of offset from the nominal
    %% sampling time and decision threshold.
    dk=ones(length(veeList),1)*zk.'-veeList(:)*ones(1,PtrnLength);
    dk(:,find(xr == 0))=0.5-dk(:,find(xr == 0));
    dk(:,find(xr == 1))=dk(:,find(xr == 1))-0.5;
    berMap(:, jj)=mean(erfc(dk/sqrt(2*MseGaussian))/2,2);
end
eyeList=2*min([0.5-eyeLid0;eyeLid1-0.5]);
%% Compute the non-compensable jitter.
kDDJ=find(abs(diff(eyeList > 0)) > 0);
phiDDJ=phiList(kDDJ)-dphi*eyeList(kDDJ)./(eyeList(kDDJ+1)-eyeList(kDDJ));
if length(phiDDJ) == 0
    phiDDJ=[0,0];
end
if length(phiDDJ) == 1
    phiDDJ=sort([phiDDJ,-sign(phiDDJ)/2]);
end
ncDDJ=1-2*max(min([-phiDDJ(1),phiDDJ(2)]),0);
%% Display the bit error ratio map, if requested.
if showEye > 0
    figure(showEye-1+ii);
    clf;
    imagesc(phiList,veeList+0.5,log10(berMap));
    hold on
    plot(phiList,eyeLid0,'--','Color','white');
    plot(phiList,eyeLid1,'--','Color','white');
    hold off
    jetColors=jet;
    colormap(jet);
    caxis([round(log10(erfc(Q0/sqrt(2))/2)),0]);
    colorbar;
    set(gca,'YDir','normal');
    set(gca,'Color',jetColors(end,:));
    if dBscale == 10,units={'W','dBo'};
    else units={'V','dBe'};end
    tapStr=sprintf('\nxMA = %.3e %s',MeasuredxMA,units{1});
    tapStr=[tapStr,sprintf('\nW = [%.3f', W(1))];
    for jj=2:EqNf
        tapStr=[tapStr,sprintf(', %.3f',W(jj))];
    end
    tapStr=[tapStr, ']'];
    if EqNb > 0
        tapStr=[tapStr,sprintf('\nB = [%.3f',B(1))];
        for jj=2:EqNb
            tapStr=[tapStr,sprintf(', %.3f',B(jj))];
        end
        tapStr=[tapStr,']'];
    else
        tapStr=[tapStr,sprintf('\nB = []')];
    end
    eyeStr=sprintf('SNR = %.1f %s\n',dBscale*log10(Q),units{2});
    eyeStr=[eyeStr,sprintf('xWDP = %.1f %s\n',xWDP,units{2})];
    eyeStr=[eyeStr,sprintf('NC-DDJ = %.3f UI\n',ncDDJ)];
    titleStr=sprintf('[SASWDP] %s',usage);
    titleStr=[titleStr,sprintf('(%d): Bit error ratio map',ii)];
    text(-0.45,0.90,tapStr,'Color','white');
    text(-0.45,0.10,eyeStr,'Color','white');
    title(titleStr, 'Interpreter','none');
    ylabel('Normalized amplitude');
    xlabel('Time (UI)');
end
%% End of AnalyzeEye %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
