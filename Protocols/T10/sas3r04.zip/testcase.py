# Simple test script for stateye v5

# class found on python.org to "print to screen and file with one print statement"
# http://mail.python.org/pipermail/python-list/2003-February/188788.html
class writer :
	def __init__(self, *writers) :
		self.writers = writers

	def write(self, text) :
		for w in self.writers :
			w.write(text)

import sys
sys.path += ['../v5']
import warnings
warnings.filterwarnings('ignore')
import portalocker

# User defined parameters

csvfile		= 'all.csv'
altcsvfile		= 'all_alt.csv'
filename	= 'SAS2_transmittertestload.s4p'

timeResolution  = 2.0e-12

#txfilename	= 'PHY_CJTPAT_clean_6G_wfm'
txfilename	= ''
responselength	= 50
startsample     = 0 # 20000
#finishsample 	= 600000 
finishsample	= 100000
timecol		= 3
sigcol		= 4
txStep		= 'extractedStep.csv'
txNoise		= 'noise.csv'

# default values for Touchstone 1.0 files
numberPorts		= 4		# number of port in touchstone file
victim_tx_P 	= 1		# ports in touchstone file for transmitter and receiver
victim_tx_N 	= 3
victim_rx_P 	= 2
victim_rx_N 	= 4

scrambled	= 0		# is analysis based on scrambled or 8b10b data
# Changed to 8b/10b data (scrambled = 0) on December 9, 2009 document 10-007r0
# scrambled	= 1		# is analysis based on scrambled or 8b10b data
deemphasis	= 0.0		# which de-emphasis, in dB
dfetaps		= 3		# how many DFE taps
baudrate	= 6.0e9		# what baud rate
padR		= 50		# pad DC termination resistance
padCap		= 950e-15	# pad capacitance
lpf		= 10.0e9	# 1st order LPF corner frequency
pws		= 0		# pulse width shrinkage, or edge jitter in UI
BUJ		= 0.10		# Deteministic pp jitter
RJ              = 0.15/15.883   # Random RMS jitter, measured using 10101010 pattern
# Replaced RJ = 0.15/14.0 with RJ = 0.15/15.883 on December 9, 2009 document 10-007r0
#RJ		= 0.15/14.0	# Random RMS jitter, measured using 10101010 pattern
TxNorm	= 1.0		# Normalised transmit amplitude, only relevant when tx signal is being generated
BER		= -15

# Simulation parameters (probably best not to touch)
sweepResolution = 0.01		
startCursor 	= -8
finishCursor 	= 30 		
DCextrapolation = 6

############################################################
# execution starts here. Don't change anything unless you
# know what you are doing
############################################################

# try to cleanup environment, in case this is not the first time
try :
	del mySParam
except :
	print "no need to delete mySParam data structure"
try : 
	del myStateye
except :
	print "no need to delete myStateye data structure"

# load and reload all necessary modules

import pdb
from numpy import *
import numpy
from pylab import *
import time
from string import rsplit, rstrip
from scipy import linalg
from re import *

import penrose 
import stateye 
import analysis 
import touchstone
import extractJitter
import getopt

############################################################
# when running from the command line, get the options used
# and overwrite the script defaults
############################################################

outfilemodifier = ''
ion()

def usage():
    print "Arguments: -s <s4p filename> [-a N][-d N][-t N][-b N][-8]"
    print "-s <s4p filename>   input .s4p file (mandatory argument)"
    print "-a N                transmitter amplitude (in Vpp); default is 1 (ampN added to output filenames)"
    print "-d N                transmitter deemphasis (in dB); default is 0 (deempN added to output filenames)"
    print "-t N                receiver dfe taps; default is 3 (.dfeN added to output filename)"
    print "-c 8|R              coding - 8b10b (.8b10b added to output filenames) or random (.rand added to output filename)"
    print "-b N                baud rate (in bps); default is 6.0e9 (.baudN added to output filename)"
    print "                    default is random.  8b10b simulations take longer."
    print "An optional argument only contribues to the output filename if used - default settings do not."

try:
	opts, args = getopt.getopt(sys.argv[1:], "a:c:d:s:t:b:q", ["help"])
except getopt.GetoptError:
    usage()
    sys.exit(2)
for opt, arg in opts:
    if opt in ("-h", "--help"):
        usage()
        sys.exit()                  
    elif opt == "-a":  # amplitude
        TxNorm = float(arg)
        outfilemodifier += '_amp' + arg
    elif opt == "-d":  # deemp
        deemphasis = float(arg)
        outfilemodifier += '_deemp' + arg
    elif opt == "-t":  # dfetaps
        dfetaps = int(arg)
        outfilemodifier += '_dfe' + arg
    elif opt == "-c":  # coding scrambled/8b10b
        if arg == "8":
            scrambled = 0
            outfilemodifier += '_8b10b'
        elif arg == "r":
            scrambled = 1
            outfilemodifier += '_rand'
    elif opt == "-b":  # baudrate
        baudrate = float(arg)
        outfilemodifier += '_baud' + arg
    elif opt == "-s":  # --s4p filename
        filename = arg
    elif opt == "-q" : 	# quiet
        ioff()

resultPrefix = filename.replace(".s4p", "");
resultPrefix = filename.replace(".s8p", "");  # RE kludge

# output all print statements to both screen and a .log file
savedstdout = sys.stdout
fout = file(resultPrefix + outfilemodifier + '.log', 'w')
sys.stdout = writer(sys.stdout, fout)

print "Major settings: \n\tfilename=%s \n\tamp=%f \n\tdeemphasis=%f \n\tdfetaps=%d \n\tcoding=%d \n\tbaudrate=%0.2e"%(filename, TxNorm, deemphasis, dfetaps, scrambled, baudrate)

############################################################
# Main script initialise objects		
############################################################

myStateye = stateye.stateye()

if len(txfilename)>0 :
	print 'extracting step response from measurement'
	tag = time.time()
	[inputT, outputsignalF, signalF, timestep] = penrose.penrose(txfilename,responselength,startsample,finishsample,timecol,sigcol)
	print 'finished in %0.1f sec'%(time.time()-tag)

	print 'extracting jitter from measurement'
	tag = time.time()
	[RJ,BUJ] = extractJitter.extractJitter(inputT, outputsignalF, signalF, 2, RJ, timestep, responselength)
	print 'finished in %0.1f sec'%(time.time()-tag)

mySParam = touchstone.touchstone()
# load the Touchstone file
print 'loading Touchstone file'
tag = time.time()
[numberPorts, victim_tx_P, victim_rx_P, victim_tx_N, victim_rx_N] = mySParam.loadFile(filename)
print 'finished loading in %0.1f sec'%(time.time()-tag)

# print 'Nyquist Sdd21=%f'%(mySParam.frequency[long(baudrate/2)])

mySParam.map( [victim_tx_P,victim_tx_N,victim_rx_P,victim_rx_N ])
mySParam.cascadeSimple(padR,padCap,lpf)

print 'creating step responses'
tag = time.time()
# extract to Dc

# extract the differential transfer function, given the port definitions
mySParam.extractTransfer(1,2,5,6)
mySParam.addDC(DCextrapolation)
	
# generation the step, and interpolate down to necessary resolution
print 'generating time step'
if len(txfilename)>0 :
	mySParam.getStep(timeResolution, txStep, txNoise,0)
else :
	mySParam.getStep(timeResolution, [], [],TxNorm)

# calculate how many time steps in one UI
UI = int(floor(1.0/baudrate/timeResolution))

# load the step response into stateye objects
myStateye.loadStep(mySParam.step, UI, pws)
print 'finished time step in %0.1f sec'%(time.time()-tag)

# calculated the FIR tap for de-emphasis
fir = -(1.0 - 10**(-deemphasis / 20)) / 2.0

# create states and transition edges
print 'creating transitions'
tag = time.time()
if scrambled :
	myStateye.create2TapFIR( [1.0+fir, fir], dfetaps)
else :
	myStateye.create8b10b_2TapFIR( [1.0+fir, fir], dfetaps)
print 'finished in %0.1f sec'%(time.time()-tag)

# calculate the ISI pdf
print 'calculating pdf'
tag = time.time()
noise_x = [0]
noise_y = [1]
myStateye.calcpdf(sweepResolution,startCursor,finishCursor,BUJ,RJ,noise_x,noise_y)
print 'finished pdf in %0.1f sec'%(time.time()-tag)

# initially the transfer function
print 'graphing spectrum'
figure()
plot(mySParam.frequency,20*log10(absolute(mySParam.t)))
hold(1)
plot(mySParam.frequency[-len(mySParam.rl):],20*log10(absolute(mySParam.rl)))
plot(mySParam.frequency[-len(mySParam.rl):],20*log10(absolute(mySParam.h)))
legend(['Victim','Return Loss','Damping'],'center right')
xlabel('Frequency [Hz]')
ylabel('Sdd21 [dB]')
title('Channel Response')
grid(1)
axis([0,baudrate*2,-40,0])
savefig(resultPrefix + outfilemodifier + '_spectrum.png')

# pulse and step response
print 'graphing pulse and step response'
figure()
hold(0)
x = []
y = []
y2 = []
for cursor in arange(startCursor,finishCursor,0.01) :
	x += [cursor]
	y += [myStateye.pulse[myStateye.cursor2index(0,cursor)]]
	y2 += [myStateye.inputStep[myStateye.cursor2index(0,cursor+2)]]

plot(x,y)
hold(1)
plot(x,y2)
grid(1)
xlabel('Time [UI]')
ylabel('Amplitude [V]')
title('Post channel Pulse and Step Response')
savefig(resultPrefix + outfilemodifier + '_pulse_step.png')
	
# jitter statistical eye
print 'graphing stateye'
figure()
pdf_pj_log = ( log10(transpose(myStateye.pdf_pj)+1.0e-17) )
contourf(myStateye.sweep, myStateye.binaxis , pdf_pj_log,arange(-15,0,0.5))
maxamp = 0.0
minamp = myStateye.midBin

for _a in transpose(pdf_pj_log)[2:-2] :
	_maxamp = min(find(_a[myStateye.midBin:] > BER ))	
	_minamp = max(find(_a[:myStateye.midBin] > BER ))	
	if _maxamp > maxamp :
		maxamp = _maxamp
	if _minamp < minamp :
		minamp = _minamp
amplitude = myStateye.binaxis[myStateye.midBin + maxamp]-myStateye.binaxis[minamp] 
print 'Amplitude is %0.3f'%(amplitude)
Jmin = max(find( pdf_pj_log[myStateye.midBin][:len(myStateye.sweep)/2] > BER ))
Jmax = min(find( pdf_pj_log[myStateye.midBin][len(myStateye.sweep)/2:] > BER )) + len(myStateye.sweep)/2
jitter = 1.0 - (myStateye.sweep[Jmax] - myStateye.sweep[Jmin])
print 'Jitter is %0.3f'%(jitter)

grid(1)
eyeLeft = find( max( pdf_pj_log[myStateye.midBin][:len(myStateye.sweep)/2] ) == pdf_pj_log[myStateye.midBin][:len(myStateye.sweep)/2] )[0]
eyeRght = find( max( pdf_pj_log[myStateye.midBin][len(myStateye.sweep)/2:] ) == pdf_pj_log[myStateye.midBin][len(myStateye.sweep)/2:] )[0] + len(myStateye.sweep)/2
axisMax = myStateye.binaxis[ max(find(transpose(pdf_pj_log)[0]>-17)) ]
axisMin = myStateye.binaxis[ min(find(transpose(pdf_pj_log)[0]>-17)) ]
axis([myStateye.sweep[eyeLeft],myStateye.sweep[eyeRght],axisMin*1.2,axisMax*1.2])
xlabel('Time [UI]')
ylabel('Amplitude [V]')
title('Eye Opening %0.3fV, Jitter %0.3fUIpp\nTx=%0.3fmV, BER=10%d'%(amplitude, jitter,TxNorm,BER))
savefig(resultPrefix + outfilemodifier + '_stateye.png')

print('\"%s\", \"%s\", %f, %f, %d, %e, %d, %f, %f\n'\
			 %(resultPrefix + outfilemodifier, time.strftime("%Y%m%d %H:%M:%S", time.localtime()), \
			   TxNorm, deemphasis, dfetaps, baudrate, scrambled, amplitude, jitter))

# add results to output database. Simplistic handling of a file lock
# conflict - just write to a backup database instead
try:
	f = open(csvfile,'a')
	portalocker.lock (f, portalocker.LOCK_EX);
	f.writelines('\"%s\", \"%s\", %f, %f, %d, %e, %d, %f, %f\n'\
				 %(resultPrefix + outfilemodifier, time.strftime("%Y%m%d %H:%M:%S", time.localtime()), \
				   TxNorm, deemphasis, dfetaps, baudrate, scrambled, amplitude, jitter))
	f.close()
except IOError:
	print "Error opening csvfile %s, trying alternate %s"%(csvfile, altcsvfile)
	f = open(altcsvfile,'a')
	portalocker.lock (f, portalocker.LOCK_EX);
	f.writelines('\"%s\", \"%s\", %f, %f, %d, %e, %d, %f, %f\n'\
				 %(resultPrefix + outfilemodifier, time.strftime("%Y%m%d %H:%M:%S", time.localtime()), \
				   TxNorm, deemphasis, dfetaps, baudrate, scrambled, amplitude, jitter))
	f.close()

# close the .log file and return to using stdout only
sys.stdout = savedstdout
fout.close()

