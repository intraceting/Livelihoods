% SASWDP_testcase.m
clear all,close all
format compact

x1='SCRAMBLED_0RDP10m_symbols.txt';
x2='SCRAMBLED_0RDN10m_symbols.txt';
x3='SCRAMBLED_0RDP_symbols.txt';
x4='SCRAMBLED_0RDN_symbols.txt';
y1='SCRAMBLED_0RDP10m_samples.txt';
y2='SCRAMBLED_0RDN10m_samples.txt';
y3='SCRAMBLED_0RDP_samples.txt';
y4='SCRAMBLED_0RDN_samples.txt';

if 1==0 % to check oversample rate
    z=load('WaveformFile_0m-prbs10.txt')
    plot(mod([1:length(z)],12),z,'.')
    clf,plot(mod([1:length(z)],16),z,'.')
end

for i=1:2
    eval(['WaveformFile = y',num2str(i),';'])
    eval(['TxDataFile = x',num2str(i),';'])
    SymbolRate = 6;
    OverSampleRate = 16;
    Usage = 'SAS2_LDP';
    ShowEye = 1;
    [WDP, ncDDJ, MeasuredxMA] = SASWDP(WaveformFile, TxDataFile, SymbolRate, OverSampleRate, Usage, ShowEye)
end

for i=3:4
    eval(['WaveformFile = y',num2str(i),';'])
    eval(['TxDataFile = x',num2str(i),';'])
    SymbolRate = 6;
    OverSampleRate = 16;
    Usage = 'SAS2_TWDP';
    ShowEye = 1;
    [WDP, ncDDJ, MeasuredxMA] = SASWDP(WaveformFile, TxDataFile, SymbolRate, OverSampleRate, Usage, ShowEye)
end
