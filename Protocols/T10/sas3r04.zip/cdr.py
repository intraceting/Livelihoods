from numpy import *
from pylab import *

# version 071210.a

def cdr (edges,k,m,name) :
	
	period0 = min(diff(edges[10:2000]))

	period = [period0]
	
	phase = [edges[0]] 
	phaseError = []
	nperiod = []
	phaseInOld = edges[0]-period[-1]
	
	for phaseIn in edges :
		nperiod += [ floor( (phaseIn+0.5*period[-1] - phaseInOld) / period[-1]) ]
		phaseInOld = phaseIn
		_phaseError = phaseIn - phase[-1] + period[-1]/2 
		phaseError += [ mod( _phaseError , period[-1]) - period[-1]/2 ]
		period += [period[-1] + phaseError[-1] * k]
		phase += [phase[-1] + phaseError[-1] * m + nperiod[-1]*period[-1]]
	
	figure()
	subplot(3,1,1)
	hold(0)
	plot(phase/mean(period))
	hold(1)
	plot(edges/mean(period))
	grid(1)
	xlabel('time [UI]')
	ylabel('Absolute Phase[UI]')
	title(name)
	
	subplot(3,1,2)
	plot(diff(edges))
	hold(1)
	plot(array(period))
	grid(1)
	xlabel('time [UI]')
	ylabel('Period\nDeviation [%mean]')
	
	subplot(3,1,3)
	plot(array(phaseError) / mean(period) )
	grid(1)
	xlabel('time [UI]')
	ylabel('Phase Error[UI]')

	savefig('cdrExtraction.png')
	
	return([phaseError, period])
	
	
