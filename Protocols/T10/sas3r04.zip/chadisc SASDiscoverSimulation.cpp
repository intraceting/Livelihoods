// SASDiscoverSimulation.cpp
// updated 2008/09/02
//
// This is a simple simulation and code implementation of the initiator 
// based expander discovery and configuration.

// There is no attempt to handle phy errors, arbitration issues, etc.
// Production level implementation need to handle errors appropriately.

// Structure names used are equivalent to those referenced in the standard.

// Basic assumptions:
// 1. BROADCAST (CHANGE) primitives initiate rediscovery/reconfiguration
// 2. Table locations for SASAddresses are deterministic for a specific 
//    topology only.  When the topology changes, the location of a SASAddress 
//    in an ASIC table cannot be assumed.
// 3. A complete discovery level occurs before the configuration of the 
//    level begins.  Multiple passes are required as the levels of expanders
//    encountered between the initiator and the end devices increases.
// 4. Configuration of a single expander occurs before proceeding to 
//    subsequent attached expanders.
// 5. The Attached structure is filled in following OOB and is available 
//    from the initialization routines.
// 6. The Iam structure is provide by the application client.

#include <malloc.h>
#include <memory.h>
#include <stdlib.h>

// include the SAS structures
#include "SASDiscoverSimulation.h"

// this defines the type of algorithm used for discover
int DiscoverAlgorithm = SAS_SIMPLE_LEVEL_DESCENT;
int SASCompatibility = SAS_11_COMPATIBLE;


// loaded by the application client, in this simulation it is provided
// in a text file, SASDeviceSetExample.ini
extern struct ApplicationClientKnowledge Iam[MAXIMUM_INITIATORS];

// obtained following OOB from the attached phy, in this simulation
// it is provided in a text file, SASDeviceSetExample.ini
extern struct Identify Attached[MAXIMUM_INITIATORS];

// buffers used to request and return SMP data
extern struct SMPRequest SMPRequestFrame;
extern struct SMPResponse SMPResponseFrame;

// resulting discover information ends up in this table
extern struct TopologyTable *SASDomain[MAXIMUM_INITIATORS];

// this is the function used to send an SMPRequest and get a response back
extern byte SMPRequest(byte PhyIdentifier,
                       quadword Source,
                       quadword Destination,
                       struct SMPRequest *SMPRequestFrame,
                       struct SMPResponse *SMPResponseFrame,
                       byte *OpenStatus,
                       byte Function,
                       ...);

// this function is used to output error information, it mimics fprintf
// functionality to an open trace file
extern int TracePrint(char *String, ...);

// this function gets the report general and discover information for
// a specific expander, the discover process begins at the subtractive
// boundary and progress downstream
static 
struct TopologyTable *DiscoverExpander(byte PhyIdentifier,
                                       quadword SourceSASAddress,
                                       quadword DestinationSASAddress)
{
   struct TopologyTable *expander = 0;
   byte phyCount = 0;
   int error = 1;

   byte openStatus = OPEN_ACCEPT;

   // get the report general information for the expander
   SMPRequest(PhyIdentifier,
              SourceSASAddress,
              DestinationSASAddress,
              &SMPRequestFrame,
              &SMPResponseFrame,
              &openStatus,
              REPORT_GENERAL);

   // don't worry about too much in the 'else' case for this example, 
   // production code needs to handle
   if((openStatus == OPEN_ACCEPT) &&
      (SMPResponseFrame.FunctionResult == SMP_FUNCTION_ACCEPTED))
   {
      if(SMPResponseFrame.Response.ReportGeneral.NumberOfPhys <= 
         MAXIMUM_EXPANDER_PHYS)
      {
         // allocate space to retrieve the expander information
         expander = (struct TopologyTable *)
                    calloc(1,
                           sizeof(struct TopologyTable));

         // make sure we only do this if the allocation is successful
         if(expander)
         {
            // save the address of this expander
            expander->SASAddress = DestinationSASAddress;

            // copy the result into the topology table
            memcpy((void *)&(expander->Device),
                   (void *)&SMPResponseFrame.Response.ReportGeneral,
                   sizeof(struct SMPResponseReportGeneral));

            // now walk through all the phys of the expander
            for(phyCount = 0;
                (phyCount < expander->Device.NumberOfPhys);
                phyCount++)
            {
               // get the discover information for each phy
               SMPRequest(PhyIdentifier,
                          SourceSASAddress,
                          DestinationSASAddress,
                          &SMPRequestFrame,
                          &SMPResponseFrame,
                          &openStatus,
                          DISCOVER,
                          phyCount);

               // don't worry about the 'else' case for this example,  
               // production code needs to handle
               if((openStatus == OPEN_ACCEPT) &&
                  (SMPResponseFrame.FunctionResult == SMP_FUNCTION_ACCEPTED))
               {
                  // clear the error flag
                  error = 0;

                  // copy the result into the topology table
                  memcpy((void *)&(expander->Phy[phyCount]),
                         (void *)&SMPResponseFrame.Response.Discover,
                         sizeof(struct SMPResponseDiscover));
               }
               else if((openStatus == OPEN_ACCEPT) &&
                       (SMPResponseFrame.FunctionResult == SMP_PHY_VACANT))
               {
                  struct Discover *discover;

                  discover = &SMPResponseFrame.Response.Discover.Result;

                  // clear the error flag
                  error = 0;

                  // set the routing attribute and link rate to indicate that 
                  // the phy is not being used, this keeps it from being 
                  // included in the routing table information, these values
                  // are not defined in the spec at this time, but are listed
                  // as reserved values
                  discover->NegotiatedPhysicalLinkRate = PHY_DOES_NOT_EXIST;
                  discover->RoutingAttribute = PHY_NOT_USED;

                  // copy the result into the topology table
                  memcpy((void *)&(expander->Phy[phyCount]),
                         (void *)&SMPResponseFrame.Response.Discover,
                         sizeof(struct SMPResponseDiscover));
               }
               else
               {
                  // if we had a problem on this link, then don't bother
                  // to do anything else, production code needs to be more
                  // robust...
                  // for this simulation example, the addresses are 
                  // described as strings, so we can print them out...
                  // not true for production code...
                  TracePrint("\n"
                             "discover error, %02Xh at %s\n",
                             SMPResponseFrame.FunctionResult,
                             (char *)&DestinationSASAddress);

                  // something happened so just bailout on this expander 
                  error = 1;

                  // release the memory we allocated for this...
                  free(expander);
                  expander = 0;
                  break;
               }
            }
         }
      }
      // the assumptions we made were exceeded, need to bump simulation
      // limits...
      else
      {
         TracePrint("\n"
                    "report general error"
                    ", NumberOfPhys %d exceeded limit %d on %s\n",
                    expander->Device.NumberOfPhys,
                    MAXIMUM_EXPANDER_PHYS,
                    (char *)&DestinationSASAddress);
      }
   }
   else
   {
      // if we had a problem getting report general for this expander,
      // something is wrong, can't go any further  down this path...
      // production code needs to be more robust...
      // for this simulation example, the addresses are 
      // described as strings, so we can print them out...
      // not true for production code...
      TracePrint("\n"
                 "report general error, open %02Xh result %02Xh at %s\n",
                 openStatus,
                 SMPResponseFrame.FunctionResult,
                 (char *)&DestinationSASAddress);
   }

   // the expander pointer is the error return, a null indicates something
   // bad happened...
   return(expander);
} // DiscoverExpander

// this routine searches upstream for the subtractive boundary 
// marking the end of the "expander device set"
static 
struct TopologyTable *FindBoundary(byte PhyIdentifier,
                                   quadword SourceSASAddress,
                                   struct TopologyTable *Expander,
                                   struct TopologyTable **DeviceSet)
{ 
   struct TopologyTable *expander = Expander;
   struct TopologyTable *nextExpander;

   struct Discover *discover;

   byte phyCount;

   int error = 0;
   int foundSubtractivePort = 0;

   quadword subtractiveSASAddress;
   byte attachedPhyIdentifier;

   // make sure the device set link is initialized
   *DeviceSet = 0;

   //  outer loop searches for subtractive phys and finds the SAS addresses
   // connected to them, validates that the subtractive phys all resolve
   // to the same expander address, then moves upstream searching for the
   // expander device set boundary
   do
   {
      // initialize the subtractive address, a zero value is not valid
      subtractiveSASAddress = 0;
      attachedPhyIdentifier = 0;

      // walk through all the phys of this expander
      for(phyCount = 0;
          (phyCount < expander->Device.NumberOfPhys);
          phyCount++)
      {
         // this is just a pointer helper                  
         discover = &(expander->Phy[phyCount].Result);

         // look for phys with expander devices attached...
         if((discover->RoutingAttribute == SUBTRACTIVE) &&
            ((discover->AttachedDeviceType == EXPANDER_DEVICE) ||
             (discover->AttachedDeviceType == OBSOLETE_EXPANDER_DEVICE)))
         {
            // make sure all the subtractive phys point to the same address
            // when we are connected to an expander device
            if(!subtractiveSASAddress)
            {
               subtractiveSASAddress = discover->AttachedSASAddress;
               attachedPhyIdentifier = discover->AttachedPhyIdentifier;
               foundSubtractivePort = 1;
            }
            // the addresses don't match... problem...
            else if(subtractiveSASAddress != 
                    discover->AttachedSASAddress)
            {
               // production code needs to deal with this better, for this
               // example, the SASAddresses are assumed to strings
               // so just print out the error information
               TracePrint("\n"
                          "topology error, diverging subtractive phys"
                          ", '%s' != '%s' \n",
                          (char *)&subtractiveSASAddress,
                          (char *)&discover->AttachedSASAddress);
               error = 1;
               break;
            }
         }
      }

      // if no error, then decide if we need to go upstream or stop
      if(!error)
      {
         // if we have a subtractive address then go upstream to see
         // if it is part of the expander device set
         if(subtractiveSASAddress)
         {
            // get the discover information
            nextExpander = DiscoverExpander(PhyIdentifier,
                                            SourceSASAddress,
                                            subtractiveSASAddress);

            // if we successfully got the information from the next 
            // expander then proceed upstream...
            if(nextExpander)
            {
               struct Discover *discover;

               // this is just a pointer helper                  
               discover = &(nextExpander->Phy[attachedPhyIdentifier].Result);

               // check to see if we are connected to the subtractive
               // port of the next expander, if we are then we have two
               // expander device sets connected together, stop here
               // and save the address of next expander in device set,
               // the return is expander
               if(discover->RoutingAttribute == SUBTRACTIVE)
               {
                  *DeviceSet = nextExpander;
                  break;
               }
               // go ahead and continue upstream looking for the boundary
               else
               {

                  // release the memory we allocated for this
                  free(expander);

                  // move upstream to the next expander
                  expander = nextExpander;
               }
            }
            // if there are no more upstream expanders stop here...
            else
            {
               break;
            }
         }
         // if we did not get a subtractive address this time around, stop
         else
         {
            // if we did find a subtractive port on a previous pass,
            // then return with expander pointing to the last device 
            // with the subtractive port
            if(foundSubtractivePort)
            {
               break;
            }
            // if we never found a subtractive port, then return with a 
            // null indicating there are no subtractive phys, don't free
            // the memory, because it is still in use by the calling routine
            else
            {
               expander = 0;
            }
         }
      }
      // if there was an error make sure we return a null expander pointer
      else
      {
         // to get here, we had to see more than one subtractive phy that
         // connect to different SAS addresses, this is a topology error
         // do cleanup on any memory allocated if necessary
         if((expander != Expander) &&
            (expander != *DeviceSet))
         {
            // release the memory we allocated for this and make sure
            // we return a null
            free(expander);
            expander = 0;
         }
      }
   }
   while(!error &&
         expander &&
         subtractiveSASAddress);

   // on return expander contains the subtractive boundary expander
   // or a null indicating there were no subtractive phys, 
   // or a null indicating there was an error
   return(expander);
} // FindBoundary

// find the table structure associated with a specific SAS address
static 
struct TopologyTable *FindExpander(struct TopologyTable *Expander,
                                   quadword SASAddress)
{
   // walk the list of expanders, when we find the one that matches, stop
   while(Expander)
   {
      // do the SAS Addresses match
      if(SASAddress == Expander->SASAddress)
      {
         break;
      }

      Expander = Expander->Next;
   }

   return(Expander);
} // FindExpander

// this routine searches the subtractive phys for the upstream
// expander address
static 
int UpstreamExpander(struct TopologyTable *Expander,
                     quadword *SASAddress,
                     byte *PhyIdentifier)
{ 
   struct Discover *discover;

   byte phyCount;

   int found = 0;

   // walk through all the phys of this expander, searching for subtractive 
   // phys return the SASAddress and PhyIdentifier for the first subtractive
   // phy encountered, they are all be the same if they have anything 
   // attached
   for(phyCount = 0;
       (phyCount < Expander->Device.NumberOfPhys);
       phyCount++)
   {
      // this is just a pointer helper                  
      discover = &(Expander->Phy[phyCount].Result);

      // look for phys with expander devices attached...
      if((discover->RoutingAttribute == SUBTRACTIVE) &&
         ((discover->AttachedDeviceType == EXPANDER_DEVICE) ||
          (discover->AttachedDeviceType == OBSOLETE_EXPANDER_DEVICE)))
      {
         *SASAddress = discover->AttachedSASAddress;
         *PhyIdentifier = discover->AttachedPhyIdentifier;
         found = 1;
         break;
      }
   }

   return(found);
} // UpstreamExpander

// this routine determines whether a SAS address is directly attached to
// an expander
static 
int DirectAttached(struct TopologyTable *Expander,
                   quadword SASAddress)
{
   int direct = 0;
   byte phyCount;

   for(phyCount = 0;
       phyCount < Expander->Device.NumberOfPhys;
       phyCount++)
   {
      // did we find the address attached locally
      if(SASAddress == 
         Expander->Phy[phyCount].Result.AttachedSASAddress)
      {
         direct = 1;
         break;
      }
   }

   return(direct);
} // DirectAttached

// this route determines whether a SAS address is already in the route table
static
int AlreadyInTable(struct TopologyTable *Expander,
                   quadword *SASAddress,
                   byte PhyIdentifier)
{
   int inTable = 0;
   int routeIndex;

   for(routeIndex = 0;
       routeIndex < Expander->Device.ExpanderRouteIndexes;
       routeIndex++)
   {
      struct RouteTableEntry *entry =
             &Expander->RouteTable[PhyIdentifier][routeIndex];

      if(entry->RoutedSASAddress == 
         SASAddress)
      {
         inTable = 1;
         break;
      }
   }

   return(inTable);
} // AlreadyInTable

// this routine determines whether the SAS address, can be optimized out
// of the route table
static 
int QualifiedAddress(struct TopologyTable *Expander,
                     byte PhyIdentifier,
                     quadword SASAddress,
                     byte RoutingAttribute,
                     byte *DisableRouteEntry)
{
   int qualified = 1;
   word routeIndex;

   if(DiscoverAlgorithm == SAS_UNIQUE_LEVEL_DESCENT)
   {
      if(((RoutingAttribute == SUBTRACTIVE) ||
          (RoutingAttribute == TABLE)) &&
         ((SASAddress == 0) ||
        (SASAddress == Expander->SASAddress) ||
          !memcmp(SASAddress, Expander->SASAddress, 8) ||
          DirectAttached(Expander, SASAddress) ||
          AlreadyInTable(Expander, SASAddress, PhyIdentifier)))
      {
         // if we made it here then we are disqualifying the address,
         // rules 2, 3, 4, and 5
         qualified = 0;
      }
     
      // if qualified, but the address is zero, then make sure it is
      // disabled
      if(qualified &&
         (SASAddress == 0))
      {
         *DisableRouteEntry = DISABLE;
      }
   }

   return(qualified);
} // QualifiedAddress


// this function is the configuration cycle from the current expander to
// the hub expander
static 
int ConfigureExpander(byte PhyIdentifier,
                      quadword SourceSASAddress,
                      struct TopologyTable *HubExpander,
                      struct TopologyTable *ThisExpander)
{
   struct TopologyTable *thisExpander = ThisExpander;
   struct TopologyTable *expander = ThisExpander;
   struct TopologyTable *configureExpander;

   struct Discover *discover;

   quadword upstreamSASAddress = 0;
   byte upstreamPhyIdentifier = 0;

   byte phyIndex;
   word routeIndex;
   byte openStatus = OPEN_ACCEPT;

   int error = 0;

   do
   {
      // move upstream from here to find the expander table to configure with
      // information from "thisExpander"
      if(!UpstreamExpander(thisExpander,
                           &upstreamSASAddress,
                           &upstreamPhyIdentifier))
      {
         break;
      }

      if(upstreamSASAddress)
      {
         // get the expander associated with the upstream address
         configureExpander = FindExpander(HubExpander,
                                          upstreamSASAddress);

         // if we found an upstream expander, then program its route
         // table
         if(configureExpander)
         {
            byte disableRouteEntry = ENABLED;

            for(phyIndex = 0;
                phyIndex < configureExpander->Device.NumberOfPhys;
                phyIndex++)
            {
               if(configureExpander->Phy[phyIndex].Result.AttachedSASAddress
              == thisExpander->SASAddress)
               {
                  // loop through all the phys of the attached expander
                  for(routeIndex = 0;
                      ((routeIndex <
                        expander->Device.NumberOfPhys) &&
                       (configureExpander->RouteIndex[phyIndex] < 
                        configureExpander->Device.ExpanderRouteIndexes));
                      routeIndex++)
                  {
                     discover = &(expander->Phy[routeIndex].Result);

                     // assume the route entry is enabled
                     disableRouteEntry = ENABLED;

                     // make sure if the attached device type is 0, that the
                     // SAS address is 0, to simplify the qualified address
                     // check
                     if(discover->AttachedDeviceType == 0)
                     {
                         discover->AttachedSASAddress = 0;
                     }

                     // check to see if the address needs to be configured
                     // in the route table, this decision is based on the
                     // optimization flag
                     if(QualifiedAddress(configureExpander,
                                         phyIndex,
                                         discover->AttachedSASAddress,
                                         discover->RoutingAttribute,
                                         &disableRouteEntry))
                     {  

                        word index = configureExpander->RouteIndex[phyIndex];
                                                                  
                        struct RouteTableEntry *entry =
                               &configureExpander->RouteTable[phyIndex][index];

                        // configure the route indexes for the expander
                        // with the attached address information
                        SMPRequest(PhyIdentifier,
                                   SourceSASAddress,
                                   configureExpander->SASAddress,
                                   &SMPRequestFrame,
                                   &SMPResponseFrame,
                                   &openStatus,
                                   CONFIGURE_ROUTE_INFORMATION,
                                   index,
                                   phyIndex,
                                   disableRouteEntry,
                                   discover->AttachedSASAddress);

                        if((openStatus != OPEN_ACCEPT) ||
                           (SMPResponseFrame.FunctionResult !=
                            SMP_FUNCTION_ACCEPTED))
                        {
                           error = 1;
                           break;
                        }

                        
                        // add the address to the internal copy of the 
                        // route table, if successfully configured
                        entry->RoutedSASAddress = 
                           discover->AttachedSASAddress;

                        // increment the route index for this phy
                        configureExpander->RouteIndex[phyIndex]++;
                     }
                  }
               }
            }
         }
      }

      // move upstream
      thisExpander = configureExpander;

   } while(!error &&
           thisExpander &&
           upstreamSASAddress);

   return(error);
} // ConfigureExpander

// this determines if the expander has a table routed phy attached to the 
// SAS address and phyIndex provided
static 
int CheckForTableAttribute(struct TopologyTable *Expander,
                           byte PhyIndex,
                           quadword SASAddress)
{
   int table = 0;
   byte phyCount;

   for(phyCount = 0;
       phyCount < Expander->Device.NumberOfPhys;
       phyCount++)
   {
      // did we find the address attached locally
      if((SASAddress == 
          Expander->Phy[phyCount].Result.AttachedSASAddress) &&
         (phyCount == PhyIndex) &&
         (Expander->Phy[phyCount].Result.RoutingAttribute == TABLE))
      {
         table = 1;
         break;
      }
   }

   return(table);
} // CheckForTableAttribute

// this discovers then configures as necessary the expanders it finds 
// within the SAS domain that are "downstream"
static 
struct TopologyTable *DiscoverAndConfigure(byte PhyIdentifier,
                                           quadword SourceSASAddress,
                                           struct TopologyTable *HubExpander,
                                           struct TopologyTable **DeviceSet)
{ 
   struct TopologyTable *currentExpander = HubExpander;
   struct TopologyTable *nextExpander;

   struct Discover *currentDiscover;

   quadword sasAddress;
   byte phyIndex;

   int error = 0;
   
   // this is a level descent traversal with a configuration stage
   // at each transition to a new level, if a configuration is required
   // by the expander

   // the discover process moves forward through the topology, but the
   // configuration process stays anchored at the hub of the
   // topology or the top most subtractive expander device
   // this ensures that as each new expander is added to the 
   // topology table list, it is in the configuration chain

   while(!error &&
         currentExpander)
   {
      // start at phy 0
      phyIndex = 0;

      // walk through all the phys of the current expander looking for 
      // new expanders to add to the topology table
      do
      {
         // this is just a pointer helper
         currentDiscover = &(currentExpander->Phy[phyIndex].Result);

         // look for phys with expander devices attached...
         if((currentDiscover->RoutingAttribute == TABLE) &&
            ((currentDiscover->AttachedDeviceType == EXPANDER_DEVICE) ||
             (currentDiscover->AttachedDeviceType == OBSOLETE_EXPANDER_DEVICE)
           ))
         {
            struct TopologyTable *thisExpander = currentExpander;
            struct TopologyTable *previousExpander = currentExpander;

            // check to see if we already have the address information
            // in our expander list
            while(thisExpander)
            {
               // if we do, then stop here
               if(currentDiscover->AttachedSASAddress == 
                  thisExpander->SASAddress)
               {
                  break;
               }

               // setup the pointer references
               previousExpander = thisExpander;
               thisExpander = thisExpander->Next;
            }

            // if we did not have the expander in our list, then get
            // the information
            if(!thisExpander)
            {
               // discover all the details about the attached expander
               // and insert into the master list
               thisExpander = 
                  DiscoverExpander(PhyIdentifier,
                                   SourceSASAddress,
                                   currentDiscover->AttachedSASAddress);

               // if we got the discover information, then add it to the
               // list
               if(thisExpander)
               {
               if(CheckForTableAttribute(thisExpander,
                                            phyIndex,
                                            currentDiscover->SASAddress))
                  {
                     // output an error message
                     TracePrint("\n"
                                "error table phys connected together\n");
                  }
                  else
                  {

               previousExpander->Next = thisExpander;

               // go through the configure cycle progressively ascending
               // to each expander starting at "thisExpander"
               ConfigureExpander(PhyIdentifier,
                                 SourceSASAddress,
                                 HubExpander,
                                 thisExpander);
               }
            }
            }
         }

         // look for subtractive phys with expander devices attached...
         else 
         if(DeviceSet &&
            (currentDiscover->RoutingAttribute == SUBTRACTIVE) &&
            ((currentDiscover->AttachedDeviceType == EXPANDER_DEVICE) ||
            (currentDiscover->AttachedDeviceType == OBSOLETE_EXPANDER_DEVICE)))
         {
            if(*DeviceSet == 0)
            {
               struct TopologyTable *thisExpander = currentExpander;
               struct TopologyTable *previousExpander = currentExpander;

               // check to see if we already have the address information
               // in our expander list
               while(thisExpander)
               {
                  // if we do, then stop here
                  if(!memcmp(&currentDiscover->AttachedSASAddress, 
                             &thisExpander->SASAddress,
                             8))
                  {
                     break;
                  }

                  // setup the pointer references
                  previousExpander = thisExpander;
                  thisExpander = thisExpander->Next;
               }

               // if we did not have the expander in our list, then get
               // the information
               if(!thisExpander)
               {
                  // discover all the details about the attached expander
                  // and insert into the master list
                  thisExpander = 
                     DiscoverExpander(PhyIdentifier,
                                      SourceSASAddress,
                                      currentDiscover->AttachedSASAddress);

                  // if we got the discover information, then set it as the
                  // other device set
                  if(thisExpander)
                  {
                     *DeviceSet = thisExpander;
                  }
               }
            }
         }

         // move to the next phy on this expander
         phyIndex++;

      } while(phyIndex < 
              currentExpander->Device.NumberOfPhys);

      // cycle to the next expander to discover
      currentExpander = currentExpander->Next;
   }

   // return the top of expander list
   return(HubExpander);
} // DiscoverAndConfigure

// this routine appends the leaf to the tree domain
static 
void ConcatenateSASDomains(struct TopologyTable *Tree,
                           struct TopologyTable *Leaf)
{
   while(Tree)
   {
      if(Tree->Next == 0)
      {
         Tree->Next = Leaf;
         break;
      }

      Tree = Tree->Next;
   }
} // ConcatenateSASDomains

// validate the route table entries for all expanders
static 
int ValidateRouteTables(byte PhyIdentifier,
                        quadword SourceSASAddress,
                        struct TopologyTable *Expander,
                        int SASCompatibility)
{
   struct ReportRouteInformation *route;

   // buffers used to request and return SMP data
   struct SMPRequest request = { 0 };
   struct SMPResponse response = { 0 };

   byte phyIndex;
   word routeIndex;

   byte openStatus = OPEN_ACCEPT;

   int valid = 1;

   if(SASCompatibility == SAS_10_COMPATIBLE)
   {
      // this is just a pointer helper
      route = &(response.Response.ReportRouteInformation.Result);

      // walk the list of expanders
      while(valid &&
            Expander)
      {
         if(Expander->Device.ConfigurableRouteTable)
         {
            struct RouteTableEntry *entry;

            word expanderRouteIndexes;

            _swab( (char *)&Expander->Device.ExpanderRouteIndexes,
                   (char *)&expanderRouteIndexes,
                   sizeof(word) );

            for(phyIndex = 0;
                (valid &&
                 (phyIndex < Expander->Device.NumberOfPhys));
                phyIndex++)
            {
               // loop through all the phys of the expander
               for(routeIndex = 0;
                   (valid &&
                    ((routeIndex <
                      Expander->RouteIndex[phyIndex]) &&
                     (routeIndex <
                      expanderRouteIndexes)));
                   routeIndex++)
               {
                  openStatus = OPEN_ACCEPT;

                  // report the route indexes for the expander
                  SMPRequest(PhyIdentifier,
                             SourceSASAddress,
                             Expander->SASAddress,
                             &request,
                             &response,
                             &openStatus,
                             REPORT_ROUTE_INFORMATION,
                             routeIndex,
                             phyIndex);

                  if((openStatus != OPEN_ACCEPT) ||
                     (response.FunctionResult !=
                      SMP_FUNCTION_ACCEPTED))
                  {
                     break;
                  }

                  entry = &(Expander->RouteTable[phyIndex][routeIndex]);

                  if((memcmp(&entry->RoutedSASAddress, 
                             &route->RoutedSASAddress,
                             8)) ||
                     (entry->ExpanderRouteEntryDisabled != 
                      route->ExpanderRouteEntryDisabled))
                  {
                     valid = 0;
                  }
               }
            }
         }

         Expander = Expander->Next;
      }
   }

   return(valid);
} // ValidateRouteTables

// validate that the change count for the hub expander is still the same 
// as when we started
static 
int ChangeCount(byte PhyIdentifier,
                quadword SourceSASAddress,
                struct TopologyTable *Expander)
{
   // buffers used to request and return SMP data
   struct SMPRequest request = { 0 };
   struct SMPResponse response = { 0 };

   int change = 0;

   byte openStatus = OPEN_ACCEPT;

   // get the report general information for the expander
   SMPRequest(PhyIdentifier,
              SourceSASAddress,
              Expander->SASAddress,
              &request,
              &response,
              &openStatus,
              REPORT_GENERAL);

   // don't worry about too much in the 'else' case for this example, 
   // production code needs to handle
   if((openStatus == OPEN_ACCEPT) &&
      (response.FunctionResult == SMP_FUNCTION_ACCEPTED))
   {
      if(response.Response.ReportGeneral.ExpanderChangeCount !=
         Expander->Device.ExpanderChangeCount)
      {
         change = 1;
      }
   }

   return(change);
} // ChangeCount

// delete all the topology information and start over
void DeleteSASDomain(struct TopologyTable **Expander)
{
   struct TopologyTable *expander = *Expander;
   struct TopologyTable *nextExpander = 0;

   // walk the list of expanders
   while(expander)
   {
      nextExpander = expander->Next;

      free(expander);

      expander = nextExpander;
   }

   *Expander = 0;
} // DeleteSASDomain

// the application client for the initiator device makes a call to
// this function to begin the discover process...
// to simplify the setup for the simulation, the DiscoverProcess gets
// the Initiator number to allow multiple initiators...
void DiscoverProcess(byte Initiator,
                     byte PhyIdentifier)
{
   // check to see if an expander device is attached
   if((Attached[Initiator].DeviceType == EXPANDER_DEVICE) || 
      (Attached[Initiator].DeviceType == OBSOLETE_EXPANDER_DEVICE))
   {
      struct TopologyTable *connectedExpander;

      // get some local variables to keep things simple
      quadword sourceSASAddress = Iam[Initiator].SASAddress;
      quadword destinationSASAddress = Attached[Initiator].SASAddress;

      // expander is attached, so begin by getting the information about
      // the connected expander
      connectedExpander = DiscoverExpander(PhyIdentifier,
                                           sourceSASAddress,
                                           destinationSASAddress);

      // make sure we get the information from the expander
      if(connectedExpander)
      {
         struct TopologyTable *thisDeviceSet;
         struct TopologyTable *attachedDeviceSet = 0;

         int redoDiscover = 0;
         int changed = 0;

         do
         {
            // Go upstream on the subtractive phys until we discover that we 
            // are attached to another subtractive phy 
            // then begin the discover process from that point. This works
            // because any new address that we find naturally moves 
            // upstream due to the subtractive addressing method.
            // If during the discover cycle, it is determined that there
            // are two device sets connected, then a second discover 
            // and configuration cycle is required for the other device set.
            thisDeviceSet = FindBoundary(PhyIdentifier,
                                         sourceSASAddress,
                                         connectedExpander,
                                         &attachedDeviceSet);

            // set the root for the SAS domain as the subtractive boundary
            if(thisDeviceSet)
            {
               // output a little information about the subtractive boundary
               TracePrint("subtractive boundary at %s\n",
                          (char *)&thisDeviceSet->SASAddress);

               SASDomain[Initiator] = thisDeviceSet;
            }
            // if there was no subtractive boundary, then the root is the
            // expander connected to the initiator
            else
            {
               // output a little information about the subtractive boundary
               TracePrint("connected expander at %s\n",
                          (char *)&connectedExpander->SASAddress);

               SASDomain[Initiator] = connectedExpander;
            }

            // begin the discover and configuration cycle
            DiscoverAndConfigure(PhyIdentifier,
                                 sourceSASAddress,
                                 SASDomain[Initiator],
                                 &attachedDeviceSet);

            // if two device sets are connected, then the attached device set
            // has to be discovered and configured
            if(attachedDeviceSet)
            {
               // output a little information about the attached device set
               TracePrint("attached device set at %s\n",
                          (char *)&attachedDeviceSet->SASAddress);

               // discover and configure the attached device set
               DiscoverAndConfigure(PhyIdentifier,
                                    sourceSASAddress,
                                    attachedDeviceSet,
                                    0);

               // put the SAS domains together
               ConcatenateSASDomains(SASDomain[Initiator],
                                     attachedDeviceSet);
            }

            // if the change count of the top most expander is different
            // from when we started, then the topology was not stable
            // so do the discover again
            changed = ChangeCount(PhyIdentifier,
                                  sourceSASAddress,
                                  SASDomain[Initiator]);

            // if we used the route table optimization,
            // check the route tables for each expander phy, if they are
            // incorrect then change back to the original discover algorithm
            // and redo discover, continue to use the original algorithm
            // for any new discover
            if(!changed &&
               (DiscoverAlgorithm == SAS_UNIQUE_LEVEL_DESCENT) &&
               !ValidateRouteTables(PhyIdentifier,
                                    sourceSASAddress,
                                    SASDomain[Initiator],
                                    SASCompatibility))
            {
               redoDiscover = 1;
            
               // if the change count of the top most expander is the same
               // as when we started the validation of the route tables
               // then the topology was stable, so change the algorithm
               // before the rediscover
               if(!ChangeCount(PhyIdentifier,
                               sourceSASAddress,
                               SASDomain[Initiator]))
               {                          
                  DiscoverAlgorithm = SAS_SIMPLE_LEVEL_DESCENT;
               }

               // delete everything allocated and start over
               DeleteSASDomain(&SASDomain[Initiator]);
            }

         } while(redoDiscover ||
                 changed);
      }   
   }
} // DiscoverProcess

